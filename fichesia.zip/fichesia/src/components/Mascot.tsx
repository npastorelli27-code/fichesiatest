type MascotProps = {
  size?: number;
  className?: string;
  animate?: boolean;
};

export function Mascot({ size = 64, className = "", animate = false }: MascotProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 90"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="FishUp mascotte poisson-lanterne"
    >
      {/* Glow halo behind lure */}
      <circle cx="36" cy="10" r="10" fill="#f5c842" opacity="0.15" />
      <circle cx="36" cy="10" r="7" fill="#f5c842" opacity="0.25" />

      {/* Lure stalk */}
      <path d="M50 30 Q46 20 40 14" stroke="#2a4f7c" strokeWidth="2" strokeLinecap="round" fill="none" />

      {/* Lure orb – outer glow */}
      <circle cx="36" cy="10" r="5.5" fill="#fde68a" opacity="0.6" />
      {/* Lure orb – core */}
      <circle cx="36" cy="10" r="4" fill="#f5c842" />
      <circle cx="34.5" cy="8.5" r="1.2" fill="white" opacity="0.8" />

      {/* Body */}
      <ellipse cx="52" cy="56" rx="34" ry="24" fill="#1e3a5f" />

      {/* Belly sheen */}
      <ellipse cx="50" cy="63" rx="20" ry="11" fill="#2a5080" opacity="0.6" />

      {/* Dorsal fin */}
      <path d="M44 33 Q50 20 63 30 L60 36 Q54 26 44 33Z" fill="#163055" />

      {/* Pectoral fin */}
      <path d="M26 58 Q12 50 14 65 Q18 72 28 66 Z" fill="#163055" />

      {/* Tail fin */}
      <path d="M83 56 Q100 44 97 58 Q100 72 83 65 Z" fill="#163055" />

      {/* Eye white */}
      <circle cx="38" cy="52" r="9" fill="white" />
      {/* Iris */}
      <circle cx="39.5" cy="52" r="6" fill="#1a1a2e" />
      {/* Pupil highlight */}
      <circle cx="42" cy="49.5" r="2" fill="white" opacity="0.9" />

      {/* Smile */}
      <path d="M33 63 Q40 70 48 63" stroke="#4a7ab5" strokeWidth="2.2" fill="none" strokeLinecap="round" />

      {/* Teeth – friendly */}
      <rect x="36" y="64" width="3.5" height="3.5" rx="1" fill="white" opacity="0.85" />
      <rect x="41" y="65" width="3" height="3" rx="1" fill="white" opacity="0.7" />

      {/* Small bubbles */}
      <circle cx="18" cy="38" r="2.5" fill="#a0c4ff" opacity="0.45" />
      <circle cx="10" cy="28" r="1.8" fill="#a0c4ff" opacity="0.35" />
      <circle cx="22" cy="22" r="1.2" fill="#a0c4ff" opacity="0.3" />
    </svg>
  );
}

export function MascotInline({ size = 28, className = "" }: { size?: number; className?: string }) {
  return <Mascot size={size} className={className} />;
}
