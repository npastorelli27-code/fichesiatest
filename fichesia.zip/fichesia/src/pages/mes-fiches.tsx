import { useState, useMemo } from "react";
import { Link } from "wouter";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { useFiches, useDeleteFiche, useUpdateFiche } from "@/hooks/use-fiches";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Search,
  FileText,
  Eye,
  Trash2,
  Edit3,
  PlusCircle,
  Check,
  X,
  BookMarked
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";

export default function MesFiches() {
  const { data: fiches, isLoading } = useFiches();
  const deleteMutation = useDeleteFiche();
  const updateMutation = useUpdateFiche();

  const [searchTerm, setSearchTerm] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deletePath, setDeletePath] = useState<string>("");

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitre, setEditTitre] = useState("");
  const [editMatiere, setEditMatiere] = useState("");

  const [editingMatiere, setEditingMatiere] = useState<string | null>(null);
  const [editMatiereValue, setEditMatiereValue] = useState("");

  const groupedFiches = useMemo(() => {
    if (!fiches) return {};
    const filtered = fiches.filter(f =>
      f.titre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.matiere.toLowerCase().includes(searchTerm.toLowerCase())
    );
    return filtered.reduce((acc, fiche) => {
      if (!acc[fiche.matiere]) acc[fiche.matiere] = [];
      acc[fiche.matiere].push(fiche);
      return acc;
    }, {} as Record<string, typeof fiches>);
  }, [fiches, searchTerm]);

  const handleDelete = async () => {
    if (!deleteId || !deletePath) return;
    try {
      await deleteMutation.mutateAsync({ id: deleteId, path: deletePath });
      toast.success("Fiche supprimée");
    } catch {
      toast.error("Erreur lors de la suppression");
    } finally {
      setDeleteId(null);
      setDeletePath("");
    }
  };

  const saveMatiereRename = async (ancienNom: string) => {
    if (!editMatiereValue.trim()) {
      toast.error("Le nom de la matière ne peut pas être vide");
      return;
    }
    if (editMatiereValue.trim() === ancienNom) {
      setEditingMatiere(null);
      return;
    }
    const fichesAModifier = groupedFiches[ancienNom] || [];
    try {
      await Promise.all(
        fichesAModifier.map((fiche) =>
          updateMutation.mutateAsync({
            id: fiche.id,
            updates: { matiere: editMatiereValue.trim() }
          })
        )
      );
      toast.success(`Matière renommée en "${editMatiereValue.trim()}"`);
    } catch {
      toast.error("Erreur lors du renommage de la matière");
    } finally {
      setEditingMatiere(null);
    }
  };

  const startEdit = (id: string, currentTitre: string, currentMatiere: string) => {
    setEditingId(id);
    setEditTitre(currentTitre);
    setEditMatiere(currentMatiere);
  };

  const saveEdit = async (id: string) => {
    if (!editTitre.trim() || !editMatiere.trim()) {
      toast.error("Le titre et la matière ne peuvent pas être vides");
      return;
    }
    try {
      await updateMutation.mutateAsync({
        id,
        updates: { titre: editTitre.trim(), matiere: editMatiere.trim() }
      });
      toast.success("Fiche modifiée");
    } catch {
      toast.error("Erreur de modification");
    } finally {
      setEditingId(null);
    }
  };

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="flex h-screen w-full bg-background/50">
          <AppSidebar />
          <div className="flex flex-col flex-1 min-w-0">
            <header className="flex items-center justify-between p-4 border-b bg-white/50 dark:bg-background/50 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <SidebarTrigger />
                <h1 className="text-xl font-serif font-bold">Mes Fiches</h1>
              </div>
              <Button asChild size="sm" className="hidden sm:flex hover-elevate">
                <Link href="/creer">
                  <PlusCircle className="mr-2 h-4 w-4" /> Nouvelle fiche
                </Link>
              </Button>
            </header>

            <main className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-4xl mx-auto space-y-6">

                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    placeholder="Rechercher une fiche, une matière..."
                    className="pl-10 h-14 text-lg bg-white dark:bg-muted shadow-sm border-0 focus-visible:ring-primary/20 rounded-xl"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                {isLoading ? (
                  <div className="text-center py-12 text-muted-foreground animate-pulse">
                    Chargement de vos fiches...
                  </div>
                ) : Object.keys(groupedFiches).length === 0 ? (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center py-16 px-4"
                  >
                    <div className="bg-primary/5 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                      <BookMarked className="h-12 w-12 text-primary/40" />
                    </div>
                    <h2 className="text-2xl font-serif font-bold text-foreground mb-3">
                      {searchTerm ? "Aucun résultat" : "Votre bibliothèque est vide"}
                    </h2>
                    <p className="text-muted-foreground max-w-md mx-auto mb-8 text-lg">
                      {searchTerm
                        ? "Essayez d'autres mots-clés de recherche."
                        : "Vous n'avez pas encore généré de fiches de révision. Commencez dès maintenant !"}
                    </p>
                    {!searchTerm && (
                      <Button asChild size="lg" className="hover-elevate px-8 shadow-lg shadow-primary/20">
                        <Link href="/creer">Créer ma première fiche</Link>
                      </Button>
                    )}
                  </motion.div>
                ) : (
                  <Accordion
                    type="multiple"
                    defaultValue={Object.keys(groupedFiches)}
                    className="space-y-4"
                  >
                    {Object.entries(groupedFiches).map(([matiere, matFiches]) => (
                      <AccordionItem
                        key={matiere}
                        value={matiere}
                        className="border-0 bg-white dark:bg-muted rounded-2xl shadow-sm overflow-hidden"
                      >
                        <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-muted/30 transition-colors data-[state=open]:bg-primary/5 data-[state=open]:text-primary">
                          <div className="flex items-center gap-3 flex-1 mr-2">
                            <div className="h-8 w-8 rounded-lg bg-secondary/20 text-secondary flex items-center justify-center font-bold font-serif shrink-0">
                              {matiere.charAt(0).toUpperCase()}
                            </div>

                            {editingMatiere === matiere ? (
                              <div
                                className="flex items-center gap-2 flex-1"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <Input
                                  value={editMatiereValue}
                                  onChange={(e) => setEditMatiereValue(e.target.value)}
                                  className="h-8 w-48 bg-background text-foreground border-border font-serif text-base"
                                  autoFocus
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') saveMatiereRename(matiere);
                                    if (e.key === 'Escape') setEditingMatiere(null);
                                  }}
                                />
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-950"
                                  onClick={() => saveMatiereRename(matiere)}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950"
                                  onClick={() => setEditingMatiere(null)}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="font-serif text-xl font-semibold">{matiere}</span>
                                <span className="bg-muted dark:bg-background/30 px-2.5 py-0.5 rounded-full text-sm font-sans text-muted-foreground">
                                  {matFiches.length}
                                </span>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-7 w-7 text-muted-foreground hover:text-primary hover:bg-primary/10 ml-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingMatiere(matiere);
                                    setEditMatiereValue(matiere);
                                  }}
                                >
                                  <Edit3 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </AccordionTrigger>

                        <AccordionContent className="px-6 pb-4 pt-2">
                          <div className="grid gap-3">
                            <AnimatePresence>
                              {matFiches.map((fiche) => (
                                <motion.div
                                  key={fiche.id}
                                  layout
                                  initial={{ opacity: 0, scale: 0.98 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  exit={{ opacity: 0, scale: 0.95 }}
                                  className="group flex items-center justify-between p-4 rounded-xl border border-border/50 hover:border-primary/20 hover:shadow-md bg-background transition-all"
                                >
                                  <div className="flex items-center gap-4 flex-1 min-w-0 mr-4">
                                    <FileText className="h-5 w-5 text-muted-foreground shrink-0 group-hover:text-primary transition-colors hidden sm:block" />

                                    {editingId === fiche.id ? (
                                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 flex-1 min-w-0">
                                        <Input
                                          value={editTitre}
                                          onChange={(e) => setEditTitre(e.target.value)}
                                          className="h-8 w-full sm:flex-1 bg-background text-foreground border-border"
                                          placeholder="Titre de la fiche"
                                          autoFocus
                                          onKeyDown={(e) => e.key === 'Enter' && saveEdit(fiche.id)}
                                        />
                                        <Input
                                          value={editMatiere}
                                          onChange={(e) => setEditMatiere(e.target.value)}
                                          className="h-8 w-full sm:w-36 bg-background text-foreground border-border"
                                          placeholder="Matière"
                                          onKeyDown={(e) => e.key === 'Enter' && saveEdit(fiche.id)}
                                        />
                                        <div className="flex gap-1 shrink-0">
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-950"
                                            onClick={() => saveEdit(fiche.id)}
                                          >
                                            <Check className="h-4 w-4" />
                                          </Button>
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950"
                                            onClick={() => setEditingId(null)}
                                          >
                                            <X className="h-4 w-4" />
                                          </Button>
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="flex flex-col min-w-0">
                                        <Link href={`/fiche/${fiche.id}`} className="block font-medium text-base truncate hover:text-primary hover:underline underline-offset-4 cursor-pointer">
                                          {fiche.titre}
                                        </Link>
                                        <span className="text-xs text-muted-foreground">
                                          {format(new Date(fiche.created_at), "d MMM yyyy 'à' HH:mm", { locale: fr })}
                                        </span>
                                      </div>
                                    )}
                                  </div>

                                  <div className="flex items-center gap-1 shrink-0 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                                    <Button asChild size="icon" variant="ghost" className="h-9 w-9 text-primary hover:bg-primary/10">
                                      <Link href={`/fiche/${fiche.id}`}>
                                        <Eye className="h-4 w-4" />
                                      </Link>
                                    </Button>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-9 w-9 text-muted-foreground hover:text-primary hover:bg-primary/10"
                                      onClick={() => startEdit(fiche.id, fiche.titre, fiche.matiere)}
                                    >
                                      <Edit3 className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-9 w-9 text-destructive hover:bg-destructive/10 hover:text-destructive"
                                      onClick={() => {
                                        setDeleteId(fiche.id);
                                        setDeletePath(fiche.contenu_path);
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </motion.div>
                              ))}
                            </AnimatePresence>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                )}
              </div>
            </main>
          </div>
        </div>

        <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Êtes-vous absolument sûr ?</AlertDialogTitle>
              <AlertDialogDescription>
                Cette action supprimera définitivement la fiche de révision de la base de données et du stockage. Cette action est irréversible.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuler</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Supprimer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

      </SidebarProvider>
    </ProtectedRoute>
  );
}