import { useRoute, Link } from "wouter";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { useFiche } from "@/hooks/use-fiches";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Printer, Maximize2, Minimize2, Loader2, Download } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabase";

export default function FicheView() {
  const [, params] = useRoute("/fiche/:id");
  const id = params?.id || "";
  const { data: fiche, isLoading, isError } = useFiche(id);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [htmlContent, setHtmlContent] = useState<string | null>(null);
  const [isFetchingHtml, setIsFetchingHtml] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = "auto"; };
  }, []);

  useEffect(() => {
    if (!fiche?.contenu_path) return;
    setIsFetchingHtml(true);
    setFetchError(null);
    supabase.storage
      .from("fiches-html")
      .download(fiche.contenu_path)
      .then(({ data, error }) => {
        if (error || !data) {
          return fetch(fiche.contenu_url)
            .then(r => r.text())
            .then(text => setHtmlContent(text))
            .catch(() => setFetchError("Impossible de charger la fiche."));
        }
        return data.text().then(text => setHtmlContent(text));
      })
      .catch(() => setFetchError("Impossible de charger la fiche."))
      .finally(() => setIsFetchingHtml(false));
  }, [fiche?.contenu_path, fiche?.contenu_url]);

  const handlePrint = () => {
    const iframe = iframeRef.current;
    if (iframe?.contentWindow) {
      iframe.contentWindow.focus();
      iframe.contentWindow.print();
    }
  };

  const handleDownloadHtml = () => {
    if (!htmlContent || !fiche) return;
    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${fiche.titre.replace(/[^a-z0-9]/gi, "_")}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-10 w-10 text-primary animate-spin" />
      </div>
    );
  }

  if (isError || !fiche) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-background gap-4">
        <h2 className="text-2xl font-serif font-bold">Fiche introuvable</h2>
        <Button asChild>
          <Link href="/mes-fiches">Retour à mes fiches</Link>
        </Button>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="h-screen w-full flex flex-col bg-gray-50 dark:bg-background">

        <motion.header
          initial={{ y: -50 }}
          animate={{ y: 0 }}
          className="h-16 flex items-center justify-between px-4 md:px-6 bg-white dark:bg-card border-b border-border shadow-sm z-10 shrink-0"
        >
          <div className="flex items-center gap-4">
            <Button asChild variant="ghost" size="icon" className="rounded-full hover:bg-muted dark:hover:bg-muted">
              <Link href="/mes-fiches">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div className="flex flex-col">
              <h1 className="font-serif font-bold text-lg md:text-xl truncate max-w-[200px] md:max-w-md lg:max-w-2xl">
                {fiche.titre}
              </h1>
              <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">
                {fiche.matiere}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              disabled={!htmlContent}
              className="hover:bg-muted dark:hover:bg-muted dark:border-border"
            >
              <Printer className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Imprimer / PDF</span>
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadHtml}
              disabled={!htmlContent}
              className="hover:bg-muted dark:hover:bg-muted dark:border-border"
            >
              <Download className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Télécharger HTML</span>
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="hidden md:flex"
            >
              {isFullscreen ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
            </Button>
          </div>
        </motion.header>

        <main className={`flex-1 flex justify-center bg-muted/30 overflow-hidden ${isFullscreen ? "p-0" : "p-4 md:p-8"}`}>
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`w-full bg-white shadow-2xl overflow-hidden transition-all duration-300 ${
              isFullscreen ? "max-w-none rounded-none" : "max-w-4xl rounded-2xl border border-border/50"
            }`}
          >
            {isFetchingHtml && (
              <div className="w-full h-full flex items-center justify-center min-h-[400px]">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
              </div>
            )}

            {fetchError && !isFetchingHtml && (
              <div className="w-full h-full flex flex-col items-center justify-center min-h-[400px] gap-3 text-muted-foreground">
                <p className="font-medium text-destructive">{fetchError}</p>
                <Button asChild variant="outline" size="sm">
                  <Link href="/mes-fiches">Retour à mes fiches</Link>
                </Button>
              </div>
            )}

            {htmlContent && !isFetchingHtml && (
              <iframe
                ref={iframeRef}
                srcDoc={htmlContent}
                className="w-full h-full border-0"
                title={fiche.titre}
                sandbox="allow-same-origin allow-scripts allow-modals"
                style={{ minHeight: "calc(100vh - 64px)" }}
              />
            )}
          </motion.div>
        </main>

      </div>
    </ProtectedRoute>
  );
}