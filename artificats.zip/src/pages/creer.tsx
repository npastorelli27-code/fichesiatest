import { useState, useMemo, useRef, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/use-auth";
import { usePrompts } from "@/hooks/use-prompts";
import { useFiches, useCreateFiche } from "@/hooks/use-fiches";
import { useCreerContext, type UploadedFile } from "@/contexts/creer-context";
import { supabase } from "@/lib/supabase";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, Save, RefreshCw, Loader2, Sparkles, FileText, Upload, X, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { v4 as uuidv4 } from "uuid";

const MAX_FILES = 6;

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}

async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function extractDocxText(file: File): Promise<string> {
  const mammoth = await import("mammoth");
  const buffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer: buffer });
  return result.value.trim();
}

export default function CreerFiche() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { data: prompts } = usePrompts();
  const { data: fiches } = useFiches();
  const createFicheMutation = useCreateFiche();

  const {
    matiere, setMatiere,
    titre, setTitre,
    selectedPromptId, setSelectedPromptId,
    promptContent, setPromptContent,
    files, setFiles,
    generatedHtml, setGeneratedHtml,
    previewUrl, setPreviewUrl,
    resetAll,
  } = useCreerContext();

  const [isDragging, setIsDragging] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const matieresList = useMemo(() => {
    const s = new Set(fiches?.map(f => f.matiere) || []);
    return Array.from(s);
  }, [fiches]);

  // Initialize default prompt only if not already selected
  useEffect(() => {
    if (prompts && prompts.length > 0 && !selectedPromptId) {
      const defaultP = prompts.find(p => p.is_default) || prompts[0];
      setSelectedPromptId(defaultP.id);
      setPromptContent(defaultP.contenu);
    }
  }, [prompts, selectedPromptId, setSelectedPromptId, setPromptContent]);

  // If generatedHtml is in context but previewUrl was lost, recreate it
  useEffect(() => {
    if (generatedHtml && !previewUrl) {
      const blob = new Blob([generatedHtml], { type: "text/html" });
      setPreviewUrl(URL.createObjectURL(blob));
    }
  }, [generatedHtml, previewUrl, setPreviewUrl]);

  const handlePromptChange = (id: string) => {
    setSelectedPromptId(id);
    const p = prompts?.find(p => p.id === id);
    if (p) setPromptContent(p.contenu);
  };

  const processFiles = useCallback(async (newFiles: FileList | File[]) => {
    const arr = Array.from(newFiles);
    const remaining = MAX_FILES - files.length;
    if (remaining <= 0) {
      toast.error(`Maximum ${MAX_FILES} fichiers autorisés.`);
      return;
    }

    const toProcess = arr.slice(0, remaining);
    const valid = toProcess.filter(f => {
      const isPdf = f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf");
      const isDocx = f.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        || f.name.toLowerCase().endsWith(".docx");
      return isPdf || isDocx;
    });

    const invalidCount = toProcess.length - valid.length;
    if (invalidCount > 0) toast.warning(`${invalidCount} fichier(s) ignoré(s) : seuls PDF et .docx sont acceptés.`);
    if (!valid.length) return;

    const pending: UploadedFile[] = valid.map(f => ({
      id: uuidv4(),
      file: f,
      type: (f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf")) ? "pdf" : "docx",
      status: "pending",
      size: formatSize(f.size),
    }));
    setFiles(prev => [...prev, ...pending]);

    for (const entry of pending) {
      try {
        if (entry.type === "pdf") {
          const b64 = await fileToBase64(entry.file);
          setFiles(prev => prev.map(f => f.id === entry.id ? { ...f, base64: b64, status: "ready" } : f));
        } else {
          const text = await extractDocxText(entry.file);
          setFiles(prev => prev.map(f => f.id === entry.id ? { ...f, extractedText: text, status: "ready" } : f));
        }
      } catch {
        setFiles(prev => prev.map(f => f.id === entry.id ? { ...f, status: "error" } : f));
        toast.error(`Erreur lors du traitement de « ${entry.file.name} »`);
      }
    }
  }, [files.length, setFiles]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) processFiles(e.target.files);
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) processFiles(e.dataTransfer.files);
  };

  const removeFile = (id: string) => setFiles(prev => prev.filter(f => f.id !== id));

  const isProcessing = files.some(f => f.status === "pending");
  const readyFiles = files.filter(f => f.status === "ready");

  const handleGenerate = async () => {
    if (!titre.trim() || !matiere.trim()) {
      toast.error("Veuillez remplir la matière et le titre.");
      return;
    }
    if (!promptContent.trim()) {
      toast.error("Le prompt est vide. Sélectionnez ou rédigez un prompt.");
      return;
    }
    if (readyFiles.length === 0) {
      toast.error("Ajoutez au moins un document PDF ou Word.");
      return;
    }

    setIsGenerating(true);
    try {
      const apiKey = import.meta.env.VITE_OPENROUTER_API_KEY;
      if (!apiKey) throw new Error("Clé API OpenRouter manquante. Vérifiez votre fichier .env");

      const contentParts: any[] = [
        {
          type: "text",
          text: `Génère une fiche de révision HTML pour :\nTitre : « ${titre} »\nMatière : ${matiere}\nNombre de documents fournis : ${readyFiles.length}`,
        },
      ];

      for (const f of readyFiles) {
        if (f.type === "pdf" && f.base64) {
          contentParts.push({
            type: "image_url",
            image_url: { url: `data:application/pdf;base64,${f.base64}` },
          });
        } else if (f.type === "docx" && f.extractedText) {
          contentParts.push({
            type: "text",
            text: `\n\n--- Document Word : ${f.file.name} ---\n${f.extractedText}\n--- Fin du document ---`,
          });
        }
      }

      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": window.location.origin,
          "X-Title": "FichesIA",
        },
        body: JSON.stringify({
          model: "google/gemini-2.0-flash-001",
          messages: [
            { role: "system", content: promptContent },
            { role: "user", content: contentParts },
          ],
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Erreur HTTP ${response.status}`);
      }

      const data = await response.json();
      let html = data.choices?.[0]?.message?.content ?? "";

      // Strip any markdown code fences the model might add despite instructions
                  // Nettoyage agressif des fences markdown
      html = html
        .replace(/^```html\s*/im, "")
        .replace(/^```\s*/im, "")
        .replace(/\s*```\s*$/im, "")
        .trim();

      // Extraire le HTML si du texte parasite précède le DOCTYPE
      const doctypeIndex = html.toLowerCase().indexOf("<!doctype");
      if (doctypeIndex > 0) {
        html = html.substring(doctypeIndex);
      }

      if (!html || !html.toLowerCase().includes("<!doctype")) {
        throw new Error("L'IA n'a pas retourné de fichier HTML valide. Réessayez.");
      }

      setGeneratedHtml(html);
      // Utiliser srcdoc via blob URL pour un rendu correct
      const blob = new Blob([html], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      setPreviewUrl(url);
      toast.success("Fiche générée avec succès !");
    } catch (error: any) {
      toast.error(`Erreur : ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!generatedHtml || !user) return;
    setIsSaving(true);
    try {
      const fileId = uuidv4();
      const sanitizedMatiere = matiere.replace(/[^a-z0-9]/gi, "_").toLowerCase();
      const path = `${user.id}/${sanitizedMatiere}/${fileId}.html`;

      const blob = new Blob([generatedHtml], { type: "text/html;charset=utf-8" });
      const { error: uploadError } = await supabase.storage
        .from("fiches-html")
        .upload(path, blob, { contentType: "text/html", upsert: false });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from("fiches-html").getPublicUrl(path);

      await createFicheMutation.mutateAsync({
        titre,
        matiere,
        contenu_url: publicUrl,
        contenu_path: path,
        prompt_utilise: promptContent,
      });

      toast.success("Fiche sauvegardée !");
      resetAll();
      setLocation("/mes-fiches");
    } catch (error: any) {
      toast.error(`Erreur de sauvegarde : ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="flex h-screen w-full bg-background/50">
          <AppSidebar />
          <div className="flex flex-col flex-1 min-w-0">
            <header className="flex items-center gap-4 p-4 border-b bg-white/50 dark:bg-background/50 backdrop-blur-md sticky top-0 z-10">
              <SidebarTrigger />
              <h1 className="text-xl font-serif font-bold">Générateur IA</h1>
              {(files.length > 0 || generatedHtml) && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto text-muted-foreground hover:text-destructive"
                  onClick={resetAll}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Tout effacer
                </Button>
              )}
            </header>

            <main className="flex-1 overflow-y-auto p-4 md:p-6">
              <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">

                {/* Left Column: Form */}
                <div className="space-y-5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-6 w-6 text-secondary" />
                    <h2 className="text-2xl font-serif font-bold">Créer une fiche</h2>
                  </div>

                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6 space-y-5">

                      {/* Matière + Titre */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="matiere">Matière</Label>
                          <Input
                            id="matiere"
                            list="matieres-list"
                            value={matiere}
                            onChange={e => setMatiere(e.target.value)}
                            placeholder="Ex : Droit, Histoire…"
                            className="bg-muted/50 focus:bg-background transition-colors"
                          />
                          <datalist id="matieres-list">
                            {matieresList.map(m => <option key={m} value={m} />)}
                          </datalist>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="titre">Titre du chapitre</Label>
                          <Input
                            id="titre"
                            value={titre}
                            onChange={e => setTitre(e.target.value)}
                            placeholder="Ex : La Révolution Française"
                            className="bg-muted/50 focus:bg-background transition-colors"
                          />
                        </div>
                      </div>

                      {/* Prompt selector */}
                      <div className="space-y-2">
                        <Label>Modèle de prompt</Label>
                        <Select value={selectedPromptId} onValueChange={handlePromptChange}>
                          <SelectTrigger className="bg-muted/50">
                            <SelectValue placeholder="Sélectionner un prompt" />
                          </SelectTrigger>
                          <SelectContent>
                            {prompts?.map(p => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.nom} {p.is_default && "✦"}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Editable prompt */}
                      <div className="space-y-2">
                        <Label>Instructions IA <span className="text-xs font-normal text-muted-foreground">(modifiable)</span></Label>
                        <Textarea
                          value={promptContent}
                          onChange={e => setPromptContent(e.target.value)}
                          className="h-24 resize-none bg-muted/50 text-xs font-mono"
                        />
                      </div>

                      {/* Documents */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>
                            Documents sources
                            <span className="ml-2 text-xs text-muted-foreground font-normal">
                              PDF ou Word · {files.length}/{MAX_FILES}
                            </span>
                          </Label>
                          {files.length > 0 && files.length < MAX_FILES && (
                            <button
                              type="button"
                              onClick={() => fileInputRef.current?.click()}
                              className="text-xs text-primary hover:underline"
                            >
                              + Ajouter
                            </button>
                          )}
                        </div>

                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                          onChange={handleFileChange}
                          className="hidden"
                        />

                        {/* File list */}
                        <AnimatePresence initial={false}>
                          {files.map(f => (
                            <motion.div
                              key={f.id}
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="overflow-hidden"
                            >
                              <div className={`flex items-center gap-3 px-3 py-2 rounded-lg border text-sm ${
                                f.status === "error"
                                  ? "border-destructive/40 bg-destructive/5"
                                  : f.status === "pending"
                                  ? "border-muted bg-muted/30"
                                  : "border-primary/20 bg-primary/5"
                              }`}>
                                <span className="text-xl shrink-0">{f.type === "pdf" ? "📄" : "📝"}</span>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium truncate">{f.file.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {f.size} ·{" "}
                                    {f.status === "pending" && (
                                      <span className="inline-flex items-center gap-1">
                                        <Loader2 className="h-3 w-3 animate-spin" />Traitement…
                                      </span>
                                    )}
                                    {f.status === "ready" && f.type === "pdf" && "PDF envoyé directemtn à l'IA"}
                                    {f.status === "ready" && f.type === "docx" && `Word · ${f.extractedText?.length.toLocaleString()} caractères extraits`}
                                    {f.status === "error" && "Erreur de traitement"}
                                  </p>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive"
                                  onClick={() => removeFile(f.id)}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            </motion.div>
                          ))}
                        </AnimatePresence>

                        {/* Drop zone */}
                        {files.length < MAX_FILES && (
                          <div
                            onDrop={handleDrop}
                            onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
                            onDragLeave={() => setIsDragging(false)}
                            onClick={() => fileInputRef.current?.click()}
                            className={`
                              flex flex-col items-center justify-center gap-2 py-5 rounded-xl border-2 border-dashed cursor-pointer transition-all select-none
                              ${isDragging
                                ? "border-primary bg-primary/10 scale-[1.01]"
                                : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/20"
                              }
                            `}
                          >
                            <div className={`p-2.5 rounded-full transition-colors ${isDragging ? "bg-primary/20" : "bg-primary/10"}`}>
                              <Upload className="h-5 w-5 text-primary" />
                            </div>
                            <div className="text-center">
                              <p className="text-sm font-medium">
                                {files.length === 0 ? "Déposez vos documents ici" : "Ajouter d'autres fichiers"}
                              </p>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                PDF ou Word (.docx) · jusqu'à {MAX_FILES} fichiers · Cliquez pour parcourir
                              </p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Generate */}
                      <Button
                        onClick={handleGenerate}
                        disabled={isGenerating || isProcessing || readyFiles.length === 0}
                        className="w-full h-12 text-base font-semibold shadow-md shadow-primary/20 hover:shadow-lg hover:-translate-y-0.5 transition-all bg-gradient-to-r from-primary to-primary/90"
                      >
                        {isGenerating ? (
                          <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Génération en cours…</>
                        ) : isProcessing ? (
                          <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Lecture des fichiers…</>
                        ) : (
                          <><Wand2 className="mr-2 h-5 w-5" />Générer la fiche</>
                        )}
                      </Button>

                    </CardContent>
                  </Card>
                </div>

                {/* Right Column: Preview */}
                <div className="flex flex-col" style={{ minHeight: "600px" }}>
                  <div className="flex items-center justify-between mb-4 pl-2">
                    <h2 className="text-xl font-serif font-bold">Aperçu</h2>
                    {generatedHtml && (
                      <span className="text-xs text-muted-foreground bg-green-50 text-green-700 border border-green-200 px-2 py-0.5 rounded-full">
                        Fiche conservée
                      </span>
                    )}
                  </div>

                  <Card className="flex-1 border-0 shadow-lg overflow-hidden flex flex-col relative bg-muted/20">
                    <AnimatePresence mode="wait">
                      {isGenerating ? (
                        <motion.div
                          key="loading"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="absolute inset-0 flex flex-col items-center justify-center bg-background/90 backdrop-blur-sm z-10"
                        >
                          <div className="w-16 h-16 relative">
                            <div className="absolute inset-0 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                          </div>
                          <p className="mt-4 font-semibold text-primary">Analyse en profondeur des documents…</p>
                          <p className="text-xs text-muted-foreground mt-1">{readyFiles.length} fichier(s) envoyé(s)</p>
                        </motion.div>
                      ) : !previewUrl ? (
                        <motion.div
                          key="empty"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex-1 flex flex-col items-center justify-center text-muted-foreground p-8 text-center"
                        >
                          <div className="bg-white p-4 rounded-full shadow-sm mb-4">
                            <FileText className="h-10 w-10 text-muted-foreground/40" />
                          </div>
                          <p className="font-medium">L'aperçu apparaîtra ici</p>
                          <p className="text-sm mt-1 max-w-xs">
                            {readyFiles.length > 0
                              ? `${readyFiles.length} document(s) prêt(s) — cliquez sur « Générer »`
                              : "Ajoutez vos documents PDF ou Word, puis cliquez sur Générer"}
                          </p>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="preview"
                          initial={{ opacity: 0, scale: 0.97 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="flex-1 flex flex-col"
                        >
                          <div className="flex-1 overflow-hidden m-2 rounded-lg shadow-inner border bg-white">
                                        <iframe
              src={previewUrl}
              className="w-full h-full border-0"
              title="Aperçu fiche"
              sandbox="allow-same-origin allow-scripts allow-popups"
              style={{ minHeight: "600px", height: "100%" }}
            />
                          </div>
                          <div className="p-3 bg-card border-t flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={handleGenerate}
                              disabled={isGenerating}
                              className="flex-1"
                            >
                              <RefreshCw className="mr-2 h-4 w-4" />
                              Régénérer
                            </Button>
                            <Button
                              onClick={handleSave}
                              disabled={isSaving}
                              size="sm"
                              className="flex-1 bg-secondary text-secondary-foreground hover:bg-secondary/90"
                            >
                              {isSaving
                                ? <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                : <Save className="mr-2 h-4 w-4" />}
                              Sauvegarder
                            </Button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </Card>
                </div>

              </div>
            </main>
          </div>
        </div>
      </SidebarProvider>
    </ProtectedRoute>
  );
}
