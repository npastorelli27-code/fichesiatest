import React, { createContext, useContext, useRef, useState } from "react";

export type UploadedFile = {
  id: string;
  file: File;
  type: "pdf" | "docx";
  status: "pending" | "ready" | "error";
  extractedText?: string;
  base64?: string;
  size: string;
};

type CreerState = {
  matiere: string;
  setMatiere: (v: string) => void;
  titre: string;
  setTitre: (v: string) => void;
  selectedPromptId: string;
  setSelectedPromptId: (v: string) => void;
  promptContent: string;
  setPromptContent: (v: string) => void;
  files: UploadedFile[];
  setFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  generatedHtml: string | null;
  setGeneratedHtml: (v: string | null) => void;
  previewUrl: string | null;
  setPreviewUrl: (v: string | null) => void;
  resetAll: () => void;
};

const CreerContext = createContext<CreerState | null>(null);

export function CreerProvider({ children }: { children: React.ReactNode }) {
  const [matiere, setMatiere] = useState("");
  const [titre, setTitre] = useState("");
  const [selectedPromptId, setSelectedPromptId] = useState("");
  const [promptContent, setPromptContent] = useState("");
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [generatedHtml, setGeneratedHtml] = useState<string | null>(null);
  const previewUrlRef = useRef<string | null>(null);
  const [previewUrl, _setPreviewUrl] = useState<string | null>(null);

  const setPreviewUrl = (url: string | null) => {
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
    }
    previewUrlRef.current = url;
    _setPreviewUrl(url);
  };

  const resetAll = () => {
    setMatiere("");
    setTitre("");
    setSelectedPromptId("");
    setPromptContent("");
    setFiles([]);
    setGeneratedHtml(null);
    setPreviewUrl(null);
  };

  return (
    <CreerContext.Provider value={{
      matiere, setMatiere,
      titre, setTitre,
      selectedPromptId, setSelectedPromptId,
      promptContent, setPromptContent,
      files, setFiles,
      generatedHtml, setGeneratedHtml,
      previewUrl, setPreviewUrl,
      resetAll,
    }}>
      {children}
    </CreerContext.Provider>
  );
}

export function useCreerContext() {
  const ctx = useContext(CreerContext);
  if (!ctx) throw new Error("useCreerContext must be used inside CreerProvider");
  return ctx;
}
