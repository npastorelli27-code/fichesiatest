import { Link } from "wouter";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { useFiches } from "@/hooks/use-fiches";
import { useProfile } from "@/hooks/use-profile";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Library, PlusCircle, Calendar as CalendarIcon, FileText, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { motion } from "framer-motion";
import { MascotWithSpeech } from "@/components/Mascot";

export default function Dashboard() {
  const { data: fiches, isLoading } = useFiches();
  const { data: profile } = useProfile();

  // Calculate stats
  const totalFiches = fiches?.length || 0;
  const uniqueMatieres = new Set(fiches?.map(f => f.matiere)).size || 0;
  
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const fichesThisMonth = fiches?.filter(f => {
    const date = new Date(f.created_at);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  }).length || 0;

  const recentFiches = fiches?.slice(0, 5) || [];

  const StatCard = ({ title, value, icon: Icon, delay }: any) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card className="border-0 shadow-md hover:shadow-lg transition-shadow overflow-hidden group relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-secondary/20 to-primary/5 rounded-bl-full opacity-60 pointer-events-none" />
        <CardHeader className="flex flex-row items-center justify-between pb-2 z-10">
          <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
            {title}
          </CardTitle>
          <div className="bg-primary/10 p-2 rounded-lg text-primary">
            <Icon className="h-5 w-5" />
          </div>
        </CardHeader>
        <CardContent className="z-10">
          <div className="text-4xl font-serif font-bold text-foreground">
            {isLoading ? "..." : value}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="flex h-screen w-full bg-background/50">
          <AppSidebar />
          <div className="flex flex-col flex-1 min-w-0">
            <header className="flex items-center gap-4 p-4 border-b bg-white/50 dark:bg-background/50 backdrop-blur-md sticky top-0 z-10">
              <SidebarTrigger />
              <h1 className="text-xl font-serif font-bold truncate">Tableau de bord</h1>
            </header>

            <main className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-5xl mx-auto space-y-8">
                
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                >
                  <div className="flex items-center gap-6">
                    <MascotWithSpeech
                      message={`Bienvenue sur FishUp ! Prêt à réviser, ${profile?.nom?.split(' ')[0] || 'Étudiant'} ?`}
                      size={64}
                      direction="right"
                    />
                  </div>
                  
                  <Button asChild size="lg" className="shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all text-base px-6">
                    <Link href="/creer">
                      <PlusCircle className="mr-2 h-5 w-5" />
                      Créer une fiche
                    </Link>
                  </Button>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <StatCard title="Total des fiches" value={totalFiches} icon={FileText} delay={0.1} />
                  <StatCard title="Matières différentes" value={uniqueMatieres} icon={Library} delay={0.2} />
                  <StatCard title="Fiches ce mois" value={fichesThisMonth} icon={CalendarIcon} delay={0.3} />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <Card className="border-0 shadow-md">
                    <CardHeader className="flex flex-row items-center justify-between border-b bg-muted/30">
                      <CardTitle className="text-xl font-serif flex items-center gap-2">
                        <BookOpen className="h-5 w-5 text-primary" />
                        Fiches récentes
                      </CardTitle>
                      <Button asChild variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                        <Link href="/mes-fiches">
                          Voir tout <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </CardHeader>
                    <CardContent className="p-0">
                      {isLoading ? (
                        <div className="p-8 text-center text-muted-foreground">Chargement...</div>
                      ) : recentFiches.length > 0 ? (
                        <div className="divide-y divide-border">
                          {recentFiches.map((fiche, i) => (
                            <Link key={fiche.id} href={`/fiche/${fiche.id}`}>
                              <div className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors cursor-pointer group">
                                <div className="flex items-center gap-4">
                                  <div className="h-10 w-10 rounded-full bg-secondary/20 text-secondary flex items-center justify-center font-bold font-serif group-hover:scale-110 transition-transform">
                                    {fiche.matiere.substring(0, 1).toUpperCase()}
                                  </div>
                                  <div>
                                    <p className="font-semibold text-foreground group-hover:text-primary transition-colors">
                                      {fiche.titre}
                                    </p>
                                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                                      <span className="bg-muted px-2 py-0.5 rounded text-xs">{fiche.matiere}</span>
                                      <span>•</span>
                                      <span>{format(new Date(fiche.created_at), "d MMMM yyyy", { locale: fr })}</span>
                                    </div>
                                  </div>
                                </div>
                                <ArrowRight className="h-5 w-5 text-muted-foreground opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                              </div>
                            </Link>
                          ))}
                        </div>
                      ) : (
                        <div className="p-12 text-center">
                          <div className="bg-primary/5 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                            <FileText className="h-8 w-8 text-primary/40" />
                          </div>
                          <p className="text-lg font-medium text-foreground mb-2">Aucune fiche pour le moment</p>
                          <p className="text-muted-foreground mb-6">Commencez par générer votre première fiche de révision.</p>
                          <Button asChild variant="outline" className="hover-elevate">
                            <Link href="/creer">Créer une fiche</Link>
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>

              </div>
            </main>
          </div>
        </div>
      </SidebarProvider>
    </ProtectedRoute>
  );
}
