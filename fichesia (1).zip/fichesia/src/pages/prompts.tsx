import { useState } from "react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { usePrompts, useCreatePrompt, useUpdatePrompt, useDeletePrompt } from "@/hooks/use-prompts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Settings2, PlusCircle, Edit, Trash2, CheckCircle2, Star } from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import type { Prompt } from "@/lib/supabase";

export default function Prompts() {
  const { data: prompts, isLoading } = usePrompts();
  const createMutation = useCreatePrompt();
  const updateMutation = useUpdatePrompt();
  const deleteMutation = useDeletePrompt();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPrompt, setEditingPrompt] = useState<Prompt | null>(null);
  
  const [nom, setNom] = useState("");
  const [matiere, setMatiere] = useState("");
  const [contenu, setContenu] = useState("");

  const [deleteId, setDeleteId] = useState<string | null>(null);

  const openNewDialog = () => {
    setEditingPrompt(null);
    setNom("");
    setMatiere("");
    setContenu("");
    setIsDialogOpen(true);
  };

  const openEditDialog = (prompt: Prompt) => {
    setEditingPrompt(prompt);
    setNom(prompt.nom);
    setMatiere(prompt.matiere);
    setContenu(prompt.contenu);
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!nom || !contenu) {
      toast.error("Nom et contenu obligatoires");
      return;
    }

    try {
      if (editingPrompt) {
        await updateMutation.mutateAsync({
          id: editingPrompt.id,
          updates: { nom, matiere, contenu }
        });
        toast.success("Prompt mis à jour");
      } else {
        await createMutation.mutateAsync({
          nom,
          matiere: matiere || "Général",
          contenu,
          is_default: false
        });
        toast.success("Nouveau prompt créé");
      }
      setIsDialogOpen(false);
    } catch (error) {
      toast.error("Une erreur est survenue");
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteMutation.mutateAsync(deleteId);
      toast.success("Prompt supprimé");
    } catch (error) {
      toast.error("Erreur de suppression");
    } finally {
      setDeleteId(null);
    }
  };

  const setAsDefault = async (id: string) => {
    try {
      // Unset current default
      const currentDefault = prompts?.find(p => p.is_default);
      if (currentDefault) {
        await updateMutation.mutateAsync({ id: currentDefault.id, updates: { is_default: false } });
      }
      // Set new default
      await updateMutation.mutateAsync({ id, updates: { is_default: true } });
      toast.success("Prompt par défaut mis à jour");
    } catch (error) {
      toast.error("Erreur de mise à jour");
    }
  };

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="flex h-screen w-full bg-background/50">
          <AppSidebar />
          <div className="flex flex-col flex-1 min-w-0">
            <header className="flex items-center justify-between p-4 border-b bg-white/50 dark:bg-background/50 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <SidebarTrigger />
                <h1 className="text-xl font-serif font-bold flex items-center gap-2">
                  <Settings2 className="h-5 w-5 text-primary" />
                  Gérer les Prompts
                </h1>
              </div>
              <Button onClick={openNewDialog} className="hover-elevate shadow-md">
                <PlusCircle className="mr-2 h-4 w-4" />
                Nouveau
              </Button>
            </header>

            <main className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-5xl mx-auto">
                
                <div className="mb-8">
                  <h2 className="text-2xl font-serif font-bold mb-2">Vos instructions IA personnalisées</h2>
                  <p className="text-muted-foreground">
                    Créez des modèles de prompts pour guider l'IA selon le type de fiche que vous souhaitez générer (ex: fiches de vocabulaire, fiches de dates historiques, synthèses de concepts...).
                  </p>
                </div>

                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[1,2,3].map(i => (
                      <Card key={i} className="animate-pulse h-48 bg-muted/50 border-0" />
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <AnimatePresence>
                      {prompts?.map((prompt) => (
                        <motion.div
                          key={prompt.id}
                          layout
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                        >
                          <Card className={`h-full flex flex-col border transition-all ${prompt.is_default ? 'border-secondary/60 border-2 shadow-lg shadow-secondary/10 ring-1 ring-secondary/20' : 'border-border/50 hover:border-primary/30'}`}>
                            <CardHeader className="pb-3 flex flex-row items-start justify-between gap-4 space-y-0">
                              <div>
                                <CardTitle className="text-lg font-serif">{prompt.nom}</CardTitle>
                                <CardDescription className="mt-1">
                                  <Badge variant="outline" className="font-normal bg-white dark:bg-slate-900">{prompt.matiere}</Badge>
                                </CardDescription>
                              </div>
                              {prompt.is_default && (
                                <Badge className="bg-secondary text-secondary-foreground shrink-0 border-0 pointer-events-none no-default-hover-elevate">
                                  <Star className="h-3 w-3 mr-1 fill-current" /> Défaut
                                </Badge>
                              )}
                            </CardHeader>
                            <CardContent className="flex-1 flex flex-col">
                              <div className="bg-background/50 rounded-md p-3 text-xs font-mono text-muted-foreground line-clamp-4 flex-1 mb-4 border border-border/30">
                                {prompt.contenu}
                              </div>
                              <div className="flex items-center justify-between mt-auto pt-2 border-t border-border/50">
                                {!prompt.is_default ? (
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => setAsDefault(prompt.id)}
                                    className="text-xs text-muted-foreground hover:text-secondary"
                                  >
                                    <CheckCircle2 className="mr-1 h-3 w-3" /> Définir par défaut
                                  </Button>
                                ) : <div/>}
                                
                                <div className="flex gap-1">
                                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => openEditDialog(prompt)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10" 
                                    onClick={() => setDeleteId(prompt.id)}
                                    disabled={prompt.is_default && prompts.length === 1} // Don't delete last default
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </main>
          </div>
        </div>

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="font-serif text-xl">{editingPrompt ? 'Modifier le prompt' : 'Nouveau prompt'}</DialogTitle>
              <DialogDescription>
                Définissez les instructions que l'IA devra suivre pour générer vos fiches.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nom">Nom du modèle</Label>
                  <Input 
                    id="nom" 
                    value={nom} 
                    onChange={(e) => setNom(e.target.value)} 
                    placeholder="Ex: Fiche Vocabulaire"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="matiere">Catégorie / Matière</Label>
                  <Input 
                    id="matiere" 
                    value={matiere} 
                    onChange={(e) => setMatiere(e.target.value)} 
                    placeholder="Ex: Langues"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="contenu">Instructions (Prompt Système)</Label>
                <Textarea 
                  id="contenu" 
                  value={contenu} 
                  onChange={(e) => setContenu(e.target.value)} 
                  placeholder="Tu es un professeur de langues. Génère un tableau de vocabulaire en HTML..."
                  className="min-h-[200px] font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground">
                  Astuce : Demandez explicitement un format HTML propre, sans markdown, avec des balises structurelles claires.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Annuler</Button>
              <Button onClick={handleSave} className="bg-primary hover:bg-primary/90">Enregistrer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Supprimer ce prompt ?</AlertDialogTitle>
              <AlertDialogDescription>
                Vous ne pourrez plus utiliser ce modèle pour vos futures fiches. Vos fiches existantes ne seront pas affectées.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuler</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Supprimer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

      </SidebarProvider>
    </ProtectedRoute>
  );
}
