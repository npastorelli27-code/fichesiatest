import { useState, useEffect } from "react";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/use-auth";
import { useProfile, useUpdateProfile } from "@/hooks/use-profile";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserCircle, Moon, Sun, Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "next-themes";

export default function Profil() {
  const { user } = useAuth();
  const { data: profile, isLoading } = useProfile();
  const updateProfileMutation = useUpdateProfile();
  const { theme, setTheme } = useTheme();

  const [nom, setNom] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (profile?.nom) {
      setNom(profile.nom);
    }
  }, [profile]);

  const handleSave = async () => {
    if (!nom.trim()) return;
    setIsSaving(true);
    try {
      await updateProfileMutation.mutateAsync({ nom });
      toast.success("Profil mis à jour");
    } catch (error) {
      toast.error("Erreur lors de la mise à jour");
    } finally {
      setIsSaving(false);
    }
  };

  const getInitials = (name: string) => name ? name.substring(0, 2).toUpperCase() : 'U';

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="flex h-screen w-full bg-background/50">
          <AppSidebar />
          <div className="flex flex-col flex-1 min-w-0">
            <header className="flex items-center gap-4 p-4 border-b bg-white/50 dark:bg-background/50 backdrop-blur-md sticky top-0 z-10">
              <SidebarTrigger />
              <h1 className="text-xl font-serif font-bold flex items-center gap-2">
                <UserCircle className="h-5 w-5 text-primary" />
                Mon Profil
              </h1>
            </header>

            <main className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-2xl mx-auto space-y-6">
                
                <Card className="border-0 shadow-lg overflow-hidden">
                  <div className="h-32 bg-gradient-to-r from-primary to-secondary/80" />
                  <CardContent className="px-8 pb-8 relative pt-0">
                    <div className="flex justify-between items-end mb-6">
                      <Avatar className="h-24 w-24 border-4 border-white dark:border-slate-900 shadow-lg -mt-12 bg-background">
                        <AvatarImage src={profile?.avatar_url || ''} />
                        <AvatarFallback className="text-2xl font-serif text-primary bg-secondary/20">
                          {isLoading ? "..." : getInitials(nom)}
                        </AvatarFallback>
                      </Avatar>
                      <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-0 mb-2">Membre</Badge>
                    </div>

                    <div className="space-y-6">
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="email">Email de connexion</Label>
                          <Input 
                            id="email" 
                            value={user?.email || ''} 
                            disabled 
                            className="bg-muted/50 text-muted-foreground"
                          />
                          <p className="text-xs text-muted-foreground">L'email ne peut être modifié.</p>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="nom">Nom d'affichage</Label>
                          <Input 
                            id="nom" 
                            value={nom} 
                            onChange={(e) => setNom(e.target.value)} 
                            placeholder="Votre nom"
                            className="focus-visible:ring-primary/30"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button 
                          onClick={handleSave} 
                          disabled={isSaving || nom === profile?.nom || !nom.trim()}
                          className="hover-elevate shadow-md shadow-primary/20"
                        >
                          {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                          Enregistrer les modifications
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-md">
                  <CardHeader>
                    <CardTitle className="font-serif text-xl">Préférences d'affichage</CardTitle>
                    <CardDescription>Personnalisez l'apparence de l'application</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between p-4 border rounded-xl bg-muted/20">
                      <div className="flex items-center gap-3">
                        {theme === 'dark' ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-primary" />}
                        <div>
                          <p className="font-medium text-foreground">Thème sombre</p>
                          <p className="text-sm text-muted-foreground">Activer le mode nuit pour réduire la fatigue visuelle</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant={theme === 'light' ? 'default' : 'outline'} 
                          size="sm" 
                          onClick={() => setTheme('light')}
                          className="rounded-full px-4"
                        >
                          Clair
                        </Button>
                        <Button 
                          variant={theme === 'dark' ? 'default' : 'outline'} 
                          size="sm" 
                          onClick={() => setTheme('dark')}
                          className="rounded-full px-4"
                        >
                          Sombre
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

              </div>
            </main>
          </div>
        </div>
      </SidebarProvider>
    </ProtectedRoute>
  );
}

// Internal inline Badge since it's used uniquely here for aesthetics
function Badge({ children, className }: any) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${className}`}>
      {children}
    </span>
  )
}
