import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Mail } from "lucide-react";
import { Mascot } from "@/components/Mascot";
import { SiGoogle } from "react-icons/si";
import { toast } from "sonner";
import { motion } from "framer-motion";

const BUBBLES = [
  { left: "8%", size: 8, duration: 7, delay: 0 },
  { left: "18%", size: 5, duration: 9, delay: 2 },
  { left: "30%", size: 12, duration: 11, delay: 1 },
  { left: "45%", size: 6, duration: 8, delay: 3.5 },
  { left: "58%", size: 9, duration: 10, delay: 0.5 },
  { left: "70%", size: 4, duration: 7.5, delay: 2.5 },
  { left: "82%", size: 7, duration: 12, delay: 1.5 },
  { left: "90%", size: 5, duration: 9, delay: 4 },
  { left: "25%", size: 3, duration: 6, delay: 3 },
  { left: "62%", size: 10, duration: 13, delay: 0.8 },
];

export default function Login() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }

    setIsLoading(true);
    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        toast.success("Inscription réussie ! Vérifiez vos emails.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        toast.success("Connexion réussie !");
      }
    } catch (error: any) {
      toast.error(error.message || "Une erreur est survenue");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) throw error;
    } catch (error: any) {
      toast.error(error.message || "Erreur de connexion Google");
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #0a0e27 0%, #0d1b4b 50%, #0a2a4a 100%)",
      }}
    >
      {/* Caustic light shimmer at top */}
      <div
        className="caustic-light absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at center, rgba(100,200,255,0.18) 0%, rgba(50,100,200,0.08) 50%, transparent 70%)",
          filter: "blur(40px)",
        }}
      />

      {/* Animated bubbles */}
      {BUBBLES.map((b, i) => (
        <div
          key={i}
          className="bubble pointer-events-none"
          style={{
            left: b.left,
            width: b.size,
            height: b.size,
            animationDuration: `${b.duration}s`,
            animationDelay: `${b.delay}s`,
          }}
        />
      ))}

      {/* Seaweed bottom left */}
      <div className="absolute bottom-0 left-4 flex items-end gap-2 pointer-events-none" aria-hidden>
        {[40, 55, 35, 50].map((h, i) => (
          <div
            key={i}
            className="seaweed rounded-t-full"
            style={{
              width: 12,
              height: h,
              background: `linear-gradient(180deg, #1a6b3a, #0d4225)`,
              borderRadius: "6px 6px 2px 2px",
              animationDelay: `${i * 0.4}s`,
            }}
          />
        ))}
      </div>

      {/* Seaweed bottom right */}
      <div className="absolute bottom-0 right-4 flex items-end gap-2 pointer-events-none" aria-hidden>
        {[50, 38, 58, 30].map((h, i) => (
          <div
            key={i}
            className="seaweed rounded-t-full"
            style={{
              width: 12,
              height: h,
              background: `linear-gradient(180deg, #1a6b3a, #0d4225)`,
              borderRadius: "6px 6px 2px 2px",
              animationDelay: `${i * 0.5 + 0.2}s`,
            }}
          />
        ))}
      </div>

      {/* Main card container */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="w-full max-w-md px-4 z-10"
      >
        {/* Mascot with speech bubble above card */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <Mascot size={64} animate />
          <div className="relative bg-white/90 backdrop-blur-sm rounded-2xl px-4 py-3 shadow-lg speech-bubble-animate max-w-[200px]">
            <div className="absolute left-[-10px] top-1/2 -translate-y-1/2 border-[10px] border-transparent border-r-white/90" />
            <p className="text-sm font-semibold text-[#0d1b4b] leading-snug">
              {isSignUp
                ? "Crée ton compte, l'océan t'attend !"
                : "Connecte-toi pour accéder à tes fiches !"}
            </p>
          </div>
        </div>

        {/* Glass morphism card */}
        <div
          className="rounded-3xl border border-white/20 p-8 shadow-2xl"
          style={{
            background: "rgba(255,255,255,0.08)",
            backdropFilter: "blur(24px)",
          }}
        >
          {/* Logo */}
          <div className="flex items-center justify-center gap-2 mb-8">
            <span className="font-serif font-bold text-3xl tracking-tight text-white">
              Fish<span style={{ color: "#f5c842" }}>Up</span>
            </span>
          </div>

          <h2 className="text-xl font-serif font-bold text-white text-center mb-1">
            {isSignUp ? "Créer un compte" : "Bienvenue"}
          </h2>
          <p className="text-white/60 text-sm text-center mb-6">
            {isSignUp
              ? "Rejoignez FishUp pour générer vos fiches"
              : "Connectez-vous pour accéder à vos fiches de révision"}
          </p>

          <div className="space-y-5">
            {/* Google button */}
            <button
              onClick={handleGoogleAuth}
              type="button"
              className="w-full h-12 flex items-center justify-center gap-3 rounded-xl border border-white/25 bg-white/10 text-white font-medium text-sm hover:bg-white/20 transition-all"
            >
              <SiGoogle className="h-4 w-4 text-white" />
              Continuer avec Google
            </button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-white/20" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="px-3 text-white/40 font-medium" style={{ background: "transparent" }}>
                  Ou par email
                </span>
              </div>
            </div>

            <form onSubmit={handleEmailAuth} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-white/80 text-sm">
                  Email
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-white/40" />
                  <input
                    id="email"
                    type="email"
                    placeholder="vous@exemple.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-12 pl-10 pr-4 rounded-xl border border-white/20 bg-white/10 text-white placeholder:text-white/30 outline-none focus:border-white/50 focus:bg-white/15 transition-all text-sm"
                    required
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-white/80 text-sm">
                  Mot de passe
                </Label>
                <input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-12 px-4 rounded-xl border border-white/20 bg-white/10 text-white placeholder:text-white/30 outline-none focus:border-white/50 focus:bg-white/15 transition-all text-sm"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full h-12 rounded-xl font-semibold text-[#0d1b4b] flex items-center justify-center gap-2 transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
                style={{ background: "linear-gradient(135deg, #f5c842, #e8a020)" }}
              >
                {isLoading && <Loader2 className="h-5 w-5 animate-spin" />}
                {isSignUp ? "S'inscrire" : "Se connecter"}
              </button>
            </form>

            <div className="text-center text-sm">
              <span className="text-white/50">
                {isSignUp ? "Déjà un compte ?" : "Pas encore de compte ?"}
              </span>{" "}
              <button
                type="button"
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-yellow-300 hover:text-yellow-200 font-semibold transition-colors underline-offset-4 hover:underline"
              >
                {isSignUp ? "Se connecter" : "S'inscrire"}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
