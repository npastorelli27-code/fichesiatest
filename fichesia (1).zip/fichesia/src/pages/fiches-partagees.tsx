import { useState, useMemo } from "react";
import { Link } from "wouter";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { useFiches, type Fiche } from "@/hooks/use-fiches";
import {
  useSharedFichesReceived,
  useSharedFichesSent,
  useShareFiche,
  useDeleteSharedFiche,
} from "@/hooks/use-shared-fiches";
import { useProfile } from "@/hooks/use-profile";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Share2,
  Eye,
  Trash2,
  Send,
  Inbox,
  Users,
  FileText,
  Loader2,
  ChevronsUpDown,
  Check,
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { MascotWithSpeech } from "@/components/Mascot";
import { cn } from "@/lib/utils";

export default function FichesPartagees() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const { data: mesFiches } = useFiches();
  const { data: received, isLoading: loadingReceived } = useSharedFichesReceived();
  const { data: sent, isLoading: loadingSent } = useSharedFichesSent();
  const shareMutation = useShareFiche();
  const deleteMutation = useDeleteSharedFiche();

  const [isShareOpen, setIsShareOpen] = useState(false);
  const [fichePickerOpen, setFichePickerOpen] = useState(false);
  const [selectedFicheId, setSelectedFicheId] = useState("");
  const [toEmail, setToEmail] = useState("");
  const [message, setMessage] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const selectedFiche = mesFiches?.find(f => f.id === selectedFicheId);

  // Group and sort fiches by matière alphabetically
  const fichesByMatiere = useMemo(() => {
    if (!mesFiches) return {};
    const sorted = [...mesFiches].sort((a, b) => {
      const matCmp = a.matiere.localeCompare(b.matiere, "fr");
      if (matCmp !== 0) return matCmp;
      return a.titre.localeCompare(b.titre, "fr");
    });
    return sorted.reduce((acc, f) => {
      if (!acc[f.matiere]) acc[f.matiere] = [];
      acc[f.matiere].push(f);
      return acc;
    }, {} as Record<string, Fiche[]>);
  }, [mesFiches]);

  const handleShare = async () => {
    if (!selectedFicheId) {
      toast.error("Sélectionnez une fiche à partager.");
      return;
    }
    if (!toEmail.trim() || !toEmail.includes("@")) {
      toast.error("Entrez une adresse email valide.");
      return;
    }
    if (toEmail.toLowerCase() === user?.email?.toLowerCase()) {
      toast.error("Vous ne pouvez pas vous partager une fiche à vous-même.");
      return;
    }
    try {
      await shareMutation.mutateAsync({
        ficheId: selectedFicheId,
        toEmail: toEmail.trim().toLowerCase(),
        message: message.trim() || undefined,
        fromNom: profile?.nom || user?.email || "Un utilisateur FishUp",
        ficheTitre: selectedFiche?.titre || "",
        ficheMatiere: selectedFiche?.matiere || "",
      });
      toast.success("Fiche partagée avec succès !");
      setIsShareOpen(false);
      setSelectedFicheId("");
      setToEmail("");
      setMessage("");
    } catch (error: any) {
      toast.error(`Erreur : ${error.message}`);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteMutation.mutateAsync(deleteId);
      toast.success("Partage supprimé.");
    } catch {
      toast.error("Erreur lors de la suppression.");
    } finally {
      setDeleteId(null);
    }
  };

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="flex h-screen w-full bg-background/50">
          <AppSidebar />
          <div className="flex flex-col flex-1 min-w-0">
            <header className="flex items-center justify-between p-4 border-b bg-white/50 dark:bg-background/50 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <SidebarTrigger />
                <h1 className="text-xl font-serif font-bold">Fiches Partagées</h1>
              </div>
              <Button
                size="sm"
                className="gap-2 hover-elevate"
                onClick={() => setIsShareOpen(true)}
                disabled={!mesFiches?.length}
              >
                <Share2 className="h-4 w-4" />
                Partager une fiche
              </Button>
            </header>

            <main className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-4xl mx-auto space-y-6">
                <Tabs defaultValue="received" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 rounded-2xl bg-muted p-1">
                    <TabsTrigger value="received" className="rounded-xl flex items-center gap-2">
                      <Inbox className="h-4 w-4" />
                      Reçues
                      {!!received?.length && (
                        <span className="ml-1 bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5 font-medium">
                          {received.length}
                        </span>
                      )}
                    </TabsTrigger>
                    <TabsTrigger value="sent" className="rounded-xl flex items-center gap-2">
                      <Send className="h-4 w-4" />
                      Envoyées
                      {!!sent?.length && (
                        <span className="ml-1 bg-muted-foreground/30 text-foreground text-xs rounded-full px-2 py-0.5 font-medium">
                          {sent.length}
                        </span>
                      )}
                    </TabsTrigger>
                  </TabsList>

                  {/* === RECEIVED === */}
                  <TabsContent value="received" className="mt-6">
                    {loadingReceived ? (
                      <div className="text-center py-12 text-muted-foreground animate-pulse">Chargement...</div>
                    ) : !received?.length ? (
                      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-16">
                        <div className="flex justify-center mb-6">
                          <MascotWithSpeech message="Personne ne t'a encore partagé de fiche… Demande à tes amis !" size={72} direction="right" />
                        </div>
                        <h2 className="text-xl font-serif font-bold mb-2">Aucune fiche reçue</h2>
                        <p className="text-muted-foreground">Tes amis peuvent te partager leurs fiches par email.</p>
                      </motion.div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">{received.length} fiche{received.length > 1 ? "s" : ""} reçue{received.length > 1 ? "s" : ""}</p>
                        <AnimatePresence>
                          {received.map((share) => (
                            <motion.div key={share.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}
                              className="group bg-white dark:bg-muted rounded-2xl shadow-sm border border-border/50 p-5 hover:border-primary/20 hover:shadow-md transition-all"
                            >
                              <div className="flex items-start gap-4">
                                <Avatar className="h-10 w-10 shrink-0 border-2 border-primary/20">
                                  <AvatarImage src={share.from_profile?.avatar_url || ""} />
                                  <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
                                    {share.from_profile?.nom?.substring(0, 2).toUpperCase() || "??"}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="min-w-0 flex-1">
                                      <p className="font-semibold text-base truncate" title={share.fiche?.titre}>
                                        {share.fiche?.titre || "Fiche inconnue"}
                                      </p>
                                      <p className="text-sm text-muted-foreground">
                                        Matière : <span className="font-medium text-foreground">{share.fiche?.matiere || "—"}</span>
                                      </p>
                                    </div>
                                    <span className="text-xs text-muted-foreground shrink-0 mt-0.5">
                                      {format(new Date(share.created_at), "d MMM yyyy", { locale: fr })}
                                    </span>
                                  </div>
                                  <p className="text-sm text-muted-foreground mt-1">
                                    Partagé par <span className="font-medium text-foreground">{share.from_nom || "Utilisateur inconnu"}</span>
                                  </p>
                                  {share.message && (
                                    <div className="mt-3 p-3 bg-muted/50 rounded-xl border border-border/50 text-sm text-foreground/80 italic">
                                      "{share.message}"
                                    </div>
                                  )}
                                  <div className="flex items-center gap-2 mt-4">
                                    {share.fiche && (
                                      <Button asChild size="sm" variant="default" className="gap-2">
                                        <Link href={`/fiche/${share.fiche.id}`}>
                                          <Eye className="h-4 w-4" />Voir la fiche
                                        </Link>
                                      </Button>
                                    )}
                                    <Button size="sm" variant="ghost" className="gap-2 text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => setDeleteId(share.id)}>
                                      <Trash2 className="h-4 w-4" />Supprimer
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>
                    )}
                  </TabsContent>

                  {/* === SENT === */}
                  <TabsContent value="sent" className="mt-6">
                    {loadingSent ? (
                      <div className="text-center py-12 text-muted-foreground animate-pulse">Chargement...</div>
                    ) : !sent?.length ? (
                      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-16">
                        <div className="flex justify-center mb-6">
                          <MascotWithSpeech message="Tu n'as encore partagé aucune fiche. Partage tes révisions !" size={72} direction="right" />
                        </div>
                        <h2 className="text-xl font-serif font-bold mb-2">Aucun partage envoyé</h2>
                        <p className="text-muted-foreground">Clique sur "Partager une fiche" pour commencer.</p>
                      </motion.div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">{sent.length} fiche{sent.length > 1 ? "s" : ""} partagée{sent.length > 1 ? "s" : ""}</p>
                        <AnimatePresence>
                          {sent.map((share) => (
                            <motion.div key={share.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}
                              className="group bg-white dark:bg-muted rounded-2xl shadow-sm border border-border/50 p-5 hover:border-primary/20 hover:shadow-md transition-all"
                            >
                              <div className="flex items-start gap-4">
                                <div className="h-10 w-10 rounded-full bg-secondary/20 text-secondary flex items-center justify-center shrink-0">
                                  <FileText className="h-5 w-5" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="min-w-0 flex-1">
                                      <p className="font-semibold text-base truncate" title={share.fiche?.titre}>
                                        {share.fiche?.titre || "Fiche inconnue"}
                                      </p>
                                      <p className="text-sm text-muted-foreground">
                                        Matière : <span className="font-medium text-foreground">{share.fiche?.matiere || "—"}</span>
                                      </p>
                                    </div>
                                    <span className="text-xs text-muted-foreground shrink-0 mt-0.5">
                                      {format(new Date(share.created_at), "d MMM yyyy", { locale: fr })}
                                    </span>
                                  </div>
                                  <p className="text-sm text-muted-foreground mt-1">
                                    Envoyé à <span className="font-medium text-foreground">{share.to_email}</span>
                                  </p>
                                  {share.message && (
                                    <div className="mt-3 p-3 bg-muted/50 rounded-xl border border-border/50 text-sm text-foreground/80 italic">
                                      "{share.message}"
                                    </div>
                                  )}
                                  <div className="flex items-center gap-2 mt-4">
                                    {share.fiche && (
                                      <Button asChild size="sm" variant="outline" className="gap-2">
                                        <Link href={`/fiche/${share.fiche.id}`}>
                                          <Eye className="h-4 w-4" />Voir
                                        </Link>
                                      </Button>
                                    )}
                                    <Button size="sm" variant="ghost" className="gap-2 text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => setDeleteId(share.id)}>
                                      <Trash2 className="h-4 w-4" />Annuler le partage
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </main>
          </div>
        </div>

        {/* Dialog: Partager une fiche */}
        <Dialog open={isShareOpen} onOpenChange={(open) => { setIsShareOpen(open); if (!open) setFichePickerOpen(false); }}>
          <DialogContent className="sm:max-w-[480px]">
            <DialogHeader>
              <DialogTitle className="font-serif text-2xl flex items-center gap-2">
                <Users className="h-6 w-6 text-primary" />
                Partager une fiche
              </DialogTitle>
              <DialogDescription>
                L'autre utilisateur recevra un email. La fiche apparaîtra dans ses fiches partagées.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-5 py-2">
              {/* Fiche picker — combobox searchable groupé par matière */}
              <div className="space-y-2">
                <Label>Fiche à partager</Label>
                <Popover open={fichePickerOpen} onOpenChange={setFichePickerOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={fichePickerOpen}
                      className="w-full justify-between bg-muted/50 font-normal h-10 px-3"
                    >
                      {selectedFiche ? (
                        <span className="flex items-center gap-2 min-w-0">
                          <span className="truncate font-medium text-sm">{selectedFiche.titre}</span>
                          <span className="shrink-0 text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded-md">
                            {selectedFiche.matiere}
                          </span>
                        </span>
                      ) : (
                        <span className="text-muted-foreground text-sm">Rechercher une fiche…</span>
                      )}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[440px] p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Rechercher par titre ou matière…" className="h-9" />
                      <CommandList className="max-h-64" onWheelCapture={(e) => e.stopPropagation()}>
                        <CommandEmpty>Aucune fiche trouvée.</CommandEmpty>
                        {Object.entries(fichesByMatiere).map(([matiere, fiches]) => (
                          <CommandGroup key={matiere} heading={matiere}>
                            {fiches.map((f) => (
                              <CommandItem
                                key={f.id}
                                value={`${f.titre} ${f.matiere}`}
                                onSelect={() => {
                                  setSelectedFicheId(f.id);
                                  setFichePickerOpen(false);
                                }}
                                className="flex items-center gap-2 py-2 cursor-pointer"
                              >
                                <Check className={cn("h-3.5 w-3.5 shrink-0 text-primary", selectedFicheId === f.id ? "opacity-100" : "opacity-0")} />
                                <span className="truncate text-sm flex-1 min-w-0" title={f.titre}>{f.titre}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        ))}
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="to-email">Email du destinataire</Label>
                <Input
                  id="to-email"
                  type="email"
                  placeholder="ami@exemple.com"
                  value={toEmail}
                  onChange={e => setToEmail(e.target.value)}
                  className="bg-muted/50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">
                  Message personnel{" "}
                  <span className="text-xs text-muted-foreground font-normal">(optionnel)</span>
                </Label>
                <Textarea
                  id="message"
                  placeholder="Ex : Voici ma fiche de droit, j'espère qu'elle t'aidera !"
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="h-20 resize-none bg-muted/50"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsShareOpen(false)}>Annuler</Button>
              <Button onClick={handleShare} disabled={shareMutation.isPending} className="gap-2">
                {shareMutation.isPending ? (
                  <><Loader2 className="h-4 w-4 animate-spin" />Envoi…</>
                ) : (
                  <><Send className="h-4 w-4" />Partager</>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete confirmation */}
        <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Supprimer ce partage ?</AlertDialogTitle>
              <AlertDialogDescription>Ce partage sera supprimé. La fiche originale ne sera pas affectée.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuler</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Supprimer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

      </SidebarProvider>
    </ProtectedRoute>
  );
}
