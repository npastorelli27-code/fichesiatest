import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Missing Supabase environment variables. App features will not work.');
}

export const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey)
  : createClient('https://placeholder.supabase.co', 'placeholder-key');

export type Profile = {
  id: string;
  nom: string;
  avatar_url: string | null;
  created_at: string;
};

export type Fiche = {
  id: string;
  user_id: string;
  titre: string;
  matiere: string;
  contenu_url: string;
  contenu_path: string;
  prompt_utilise: string;
  created_at: string;
  updated_at: string;
};

export type Prompt = {
  id: string;
  user_id: string;
  nom: string;
  matiere: string;
  contenu: string;
  is_default: boolean;
  created_at: string;
};
