import { Bell } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useNotifications } from "@/hooks/use-notifications";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";

export function NotificationBell() {
  const { notifications, unreadCount, markAllSeen } = useNotifications();

  return (
    <Popover onOpenChange={(open) => { if (open) markAllSeen(); }}>
      <PopoverTrigger asChild>
        <button
          className="relative flex items-center justify-center w-10 h-10 rounded-full bg-white/90 shadow-md hover:bg-white transition-all border border-border/30 hover:shadow-lg"
          aria-label="Notifications"
        >
          <Bell className="h-5 w-5 text-foreground/80" />
          <AnimatePresence>
            {unreadCount > 0 && (
              <motion.span
                key="badge"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center px-1 shadow-sm"
              >
                {unreadCount > 9 ? "9+" : unreadCount}
              </motion.span>
            )}
          </AnimatePresence>
        </button>
      </PopoverTrigger>

      <PopoverContent align="end" className="w-80 p-0 rounded-2xl shadow-xl border border-border/50" sideOffset={8}>
        <div className="flex items-center justify-between px-4 pt-4 pb-2 border-b border-border/30">
          <span className="font-semibold text-base">Notifications</span>
          {notifications.length > 0 && (
            <span className="text-xs text-muted-foreground">{notifications.length} fiche{notifications.length > 1 ? "s" : ""} reçue{notifications.length > 1 ? "s" : ""}</span>
          )}
        </div>

        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 px-4 text-center gap-2">
            <Bell className="h-8 w-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">Aucune fiche reçue pour l'instant</p>
          </div>
        ) : (
          <ScrollArea className="max-h-72">
            <div className="divide-y divide-border/30">
              {notifications.map((notif) => (
                <Link key={notif.id} href="/fiches-partagees">
                  <div className="flex flex-col gap-1 px-4 py-3 hover:bg-muted/50 cursor-pointer transition-colors">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-medium truncate leading-tight">
                        {notif.fiche_titre || "Fiche inconnue"}
                      </p>
                      <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">
                        {format(new Date(notif.created_at), "d MMM", { locale: fr })}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {notif.fiche_matiere && <span className="text-foreground/70">{notif.fiche_matiere} · </span>}
                      Partagé par <span className="font-medium text-foreground/80">{notif.from_nom || "Utilisateur inconnu"}</span>
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </ScrollArea>
        )}

        {notifications.length > 0 && (
          <div className="p-3 border-t border-border/30">
            <Button asChild variant="ghost" size="sm" className="w-full text-primary hover:text-primary hover:bg-primary/5">
              <Link href="/fiches-partagees">Voir toutes les fiches partagées →</Link>
            </Button>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
