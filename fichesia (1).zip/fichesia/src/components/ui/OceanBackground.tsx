import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { Mascot } from "@/components/Mascot";

/* ─────────────────────────────────────────────────────────────
   SVG fish shapes — all face LEFT so swim-right's scaleX(-1)
   correctly flips them to face right.
   ───────────────────────────────────────────────────────────── */

function FishSVG({ color, w, h }: { color: string; w: number; h: number }) {
  return (
    <svg width={w} height={h} viewBox="0 0 80 40" style={{ overflow: "visible" }}>
      {/* Forked tail (right side) */}
      <polygon points="80,20 60,9 66,20 60,31" fill={color} />
      {/* Body */}
      <ellipse cx="34" cy="20" rx="28" ry="14" fill={color} />
      {/* Belly shimmer */}
      <ellipse cx="32" cy="23" rx="20" ry="7" fill="rgba(255,255,255,0.18)" />
      {/* Dorsal fin */}
      <polygon points="22,8 34,6 46,20 36,20" fill={color} opacity={0.88} />
      {/* Pectoral fin */}
      <ellipse cx="38" cy="28" rx="10" ry="5" fill={color} opacity={0.7}
        transform="rotate(20 38 28)" />
      {/* Eye */}
      <circle cx="11" cy="18" r="3.5" fill="white" />
      <circle cx="10.3" cy="18" r="2" fill="#001a20" />
      <circle cx="9.6" cy="17" r="0.7" fill="white" opacity={0.85} />
    </svg>
  );
}

function SharkSVG({ w, h }: { w: number; h: number }) {
  return (
    <svg width={w} height={h} viewBox="0 0 200 70" style={{ overflow: "visible" }}>
      {/* Body — long torpedo */}
      <ellipse cx="95" cy="40" rx="78" ry="20" fill="#6e8a9e" />
      {/* Snout — pointed left */}
      <polygon points="17,40 42,29 42,51" fill="#607888" />
      {/* Dorsal fin — tall, iconic */}
      <polygon points="68,20 82,40 116,40 106,16 82,8" fill="#4f6878" />
      {/* Pectoral fin */}
      <polygon points="85,48 122,65 116,40" fill="#4f6878" />
      {/* Second dorsal fin */}
      <polygon points="136,34 144,40 152,35 146,30" fill="#4f6878" />
      {/* Tail — crescent shape */}
      <polygon points="173,40 190,22 196,38 190,58" fill="#4f6878" />
      <ellipse cx="183" cy="40" rx="4" ry="4" fill="#607888" />
      {/* Gill slits */}
      <path d="M 50 28 Q 53 40 50 52" stroke="#3d5566" strokeWidth="1.5" fill="none" opacity={0.7} />
      <path d="M 57 27 Q 60 40 57 53" stroke="#3d5566" strokeWidth="1.5" fill="none" opacity={0.55} />
      <path d="M 64 27 Q 67 40 64 53" stroke="#3d5566" strokeWidth="1.5" fill="none" opacity={0.4} />
      {/* Eye */}
      <circle cx="32" cy="36" r="4.5" fill="#0f0f1e" />
      <circle cx="31" cy="35" r="1.5" fill="rgba(255,255,255,0.22)" />
      {/* Mouth line */}
      <path d="M 17 42 Q 32 50 46 43" stroke="#3d5566" strokeWidth="1.5" fill="none" opacity={0.6} />
    </svg>
  );
}


/* ─────────────────────────────────────────────────────────────
   Data
   ───────────────────────────────────────────────────────────── */

type Direction = "left" | "right";
type Variant = "fish" | "shark";

interface FishData {
  top: string; w: number; h: number; duration: number; delay: number;
  direction: Direction; color: string; variant: Variant;
}

// Dark mode — varied sizes, depths
const FISH_DARK: FishData[] = [
  // Small
  { top: "15%", w: 44, h: 22, duration: 22, delay: 0,  direction: "left",  color: "#4dd9ff", variant: "fish" },
  { top: "33%", w: 36, h: 18, duration: 19, delay: 7,  direction: "right", color: "#00c8ff", variant: "fish" },
  { top: "60%", w: 40, h: 20, duration: 28, delay: 14, direction: "left",  color: "#6ec8e0", variant: "fish" },
  // Medium
  { top: "26%", w: 64, h: 32, duration: 27, delay: 4,  direction: "right", color: "#1e90ff", variant: "fish" },
  { top: "68%", w: 58, h: 29, duration: 31, delay: 10, direction: "left",  color: "#5ba4d4", variant: "fish" },
  // Large
  { top: "48%", w: 95, h: 48, duration: 40, delay: 2,  direction: "right", color: "#1a6aaa", variant: "fish" },
  { top: "78%", w: 105, h: 52, duration: 48, delay: 20, direction: "left", color: "#155880", variant: "fish" },
  // Shark — rare, slow
  { top: "40%", w: 180, h: 62, duration: 60, delay: 28, direction: "right", color: "", variant: "shark" },
];

// Lanternfish — rare, very slow
const LANTERNFISH = [
  { top: "36%", duration: 68, delay: 6  },
  { top: "58%", duration: 80, delay: 42 },
];

// Light mode — tropical colours
const FISH_LIGHT: FishData[] = [
  { top: "30%", w: 55, h: 28, duration: 22, delay: 0,  direction: "left",  color: "#ff6b35", variant: "fish" },
  { top: "46%", w: 48, h: 24, duration: 19, delay: 6,  direction: "right", color: "#ffd600", variant: "fish" },
  { top: "60%", w: 66, h: 33, duration: 26, delay: 3,  direction: "left",  color: "#e040fb", variant: "fish" },
  { top: "74%", w: 40, h: 20, duration: 21, delay: 11, direction: "right", color: "#40c4ff", variant: "fish" },
  { top: "52%", w: 44, h: 22, duration: 33, delay: 16, direction: "left",  color: "#69f0ae", variant: "fish" },
  { top: "38%", w: 52, h: 26, duration: 28, delay: 22, direction: "right", color: "#ff5252", variant: "fish" },
  { top: "68%", w: 62, h: 31, duration: 36, delay: 9,  direction: "left",  color: "#ffab40", variant: "fish" },
];

/* ─────────────────────────────────────────────────────────────
   Particles / bubbles
   ───────────────────────────────────────────────────────────── */

const DARK_PARTICLES = [
  { left: "4%",  size: 3, duration: 12, delay: 0   },
  { left: "9%",  size: 2, duration: 18, delay: 2.5 },
  { left: "15%", size: 4, duration: 14, delay: 1   },
  { left: "22%", size: 2, duration: 20, delay: 4   },
  { left: "29%", size: 3, duration: 15, delay: 0.5 },
  { left: "36%", size: 2, duration: 11, delay: 3   },
  { left: "43%", size: 4, duration: 17, delay: 1.5 },
  { left: "51%", size: 2, duration: 13, delay: 5   },
  { left: "58%", size: 3, duration: 19, delay: 2   },
  { left: "65%", size: 2, duration: 10, delay: 0.8 },
  { left: "72%", size: 4, duration: 16, delay: 3.5 },
  { left: "79%", size: 2, duration: 12, delay: 6   },
  { left: "85%", size: 3, duration: 14, delay: 1.2 },
  { left: "91%", size: 2, duration: 18, delay: 4.5 },
  { left: "96%", size: 3, duration: 15, delay: 2.8 },
  { left: "33%", size: 2, duration: 22, delay: 7   },
  { left: "60%", size: 4, duration: 20, delay: 3.2 },
];

const LIGHT_BUBBLES = [
  { left: "5%",  sizes: [10, 6, 14], duration: 8,  delay: 0   },
  { left: "13%", sizes: [6,  9,  5], duration: 11, delay: 1.5 },
  { left: "22%", sizes: [12, 7,  9], duration: 9,  delay: 3   },
  { left: "34%", sizes: [5, 10,  7], duration: 10, delay: 0.8 },
  { left: "46%", sizes: [8,  5, 11], duration: 7,  delay: 4.5 },
  { left: "58%", sizes: [7, 12,  6], duration: 12, delay: 1   },
  { left: "69%", sizes: [9,  6, 10], duration: 8,  delay: 2.2 },
  { left: "80%", sizes: [5,  8,  6], duration: 10, delay: 5   },
  { left: "91%", sizes: [11, 7,  5], duration: 9,  delay: 0.3 },
];

const CAUSTIC_BLOBS = [
  { left: "8%",  top: "25%", size: 340, duration: 7,  delay: 0   },
  { left: "40%", top: "10%", size: 280, duration: 10, delay: 2.5 },
  { left: "68%", top: "35%", size: 220, duration: 8,  delay: 1   },
  { left: "20%", top: "55%", size: 300, duration: 12, delay: 3.5 },
  { left: "82%", top: "18%", size: 260, duration: 9,  delay: 4.5 },
  { left: "55%", top: "65%", size: 240, duration: 11, delay: 1.8 },
];

const SURFACE_RAYS = [
  { left: "8%",  width: 45, height: "75%", duration: 7,  delay: 0   },
  { left: "20%", width: 60, height: "60%", duration: 9,  delay: 1.3 },
  { left: "33%", width: 35, height: "80%", duration: 6,  delay: 2.8 },
  { left: "48%", width: 70, height: "65%", duration: 10, delay: 0.5 },
  { left: "60%", width: 40, height: "70%", duration: 8,  delay: 3.5 },
  { left: "73%", width: 55, height: "55%", duration: 7,  delay: 1.9 },
  { left: "86%", width: 45, height: "72%", duration: 9,  delay: 4.2 },
];

/* ─────────────────────────────────────────────────────────────
   Animal elements
   ───────────────────────────────────────────────────────────── */

function FishEl({ top, w, h, duration, delay, direction, color, variant, isDark }: FishData & { isDark: boolean }) {
  return (
    <div
      style={{
        position: "absolute",
        top,
        animationName: direction === "left" ? "swim-left" : "swim-right",
        animationDuration: `${duration}s`,
        animationDelay: `${delay}s`,
        animationTimingFunction: "linear",
        animationIterationCount: "infinite",
        animationFillMode: "both",
        opacity: isDark ? 0.42 : 0.65,
        filter: isDark
          ? "brightness(0.72) saturate(0.65)"
          : "brightness(1.05) saturate(1.3) drop-shadow(0 2px 6px rgba(0,50,70,0.35))",
        userSelect: "none",
        pointerEvents: "none",
        lineHeight: 0,
      }}
    >
      {variant === "shark"
        ? <SharkSVG w={w} h={h} />
        : <FishSVG color={color} w={w} h={h} />}
    </div>
  );
}

function LanternFishEl({ top, duration, delay }: { top: string; duration: number; delay: number }) {
  return (
    <div
      style={{
        position: "absolute",
        top,
        animation: `swim-left ${duration}s linear ${delay}s infinite both, lantern-fish-pulse 2.2s ease-in-out 0s infinite alternate`,
        userSelect: "none",
        pointerEvents: "none",
        lineHeight: 0,
        opacity: 0.75,
      }}
    >
      <Mascot size={72} />
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   Background overlays
   ───────────────────────────────────────────────────────────── */

function DarkLightRays() {
  return (
    <div className="absolute top-0 left-0 right-0 h-64 pointer-events-none overflow-hidden">
      {[15, 35, 55, 70, 85].map((left, i) => (
        <div
          key={i}
          className="light-ray absolute top-0"
          style={{
            left: `${left}%`, width: 60, height: 280,
            background: "linear-gradient(180deg, rgba(100,200,255,0.07) 0%, transparent 100%)",
            filter: "blur(18px)", animationDelay: `${i * 1.2}s`,
            borderRadius: "0 0 50% 50%", transform: "rotate(-5deg)",
          }}
        />
      ))}
    </div>
  );
}

function LightUnderwaterScene() {
  return (
    <>
      <div className="absolute top-0 left-0 right-0 pointer-events-none" style={{
        height: 90,
        background: "linear-gradient(180deg, rgba(200,245,255,0.55) 0%, rgba(100,220,240,0.2) 60%, transparent 100%)",
        filter: "blur(6px)",
      }} />
      <div className="absolute top-0 left-0 right-0 pointer-events-none" style={{
        height: 6, background: "rgba(220,250,255,0.7)", filter: "blur(3px)",
      }} />
      {SURFACE_RAYS.map((r, i) => (
        <div key={i} className="light-ray absolute top-0 pointer-events-none" style={{
          left: r.left, width: r.width, height: r.height,
          background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(100,230,255,0.08) 55%, transparent 100%)",
          filter: "blur(22px)", borderRadius: "0 0 60% 60%",
          animationDuration: `${r.duration}s`, animationDelay: `${r.delay}s`,
        }} />
      ))}
      {CAUSTIC_BLOBS.map((b, i) => (
        <div key={i} className="caustic-blob absolute pointer-events-none" style={{
          left: b.left, top: b.top, width: b.size, height: b.size,
          background: "radial-gradient(ellipse, rgba(200,245,255,0.28) 0%, rgba(100,210,230,0.10) 50%, transparent 70%)",
          filter: "blur(28px)", borderRadius: "50%",
          animationDuration: `${b.duration}s`, animationDelay: `${b.delay}s`,
        }} />
      ))}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none" style={{
        height: 180,
        background: "linear-gradient(0deg, rgba(0,60,80,0.35) 0%, transparent 100%)",
      }} />
    </>
  );
}

/* ─────────────────────────────────────────────────────────────
   Main export
   ───────────────────────────────────────────────────────────── */

export function OceanBackground() {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  if (!mounted) return null;

  const isDark = resolvedTheme === "dark";

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none select-none" style={{ zIndex: 0 }} aria-hidden>
      {/* Gradient background */}
      <div className="absolute inset-0" style={{
        background: isDark
          ? "linear-gradient(180deg, #020818 0%, #051535 55%, #071d4a 100%)"
          : "linear-gradient(180deg, #0097b2 0%, #006d85 40%, #005068 75%, #003a50 100%)",
      }} />

      {/* Overlay effects */}
      {isDark ? <DarkLightRays /> : <LightUnderwaterScene />}

      {/* Fish */}
      {(isDark ? FISH_DARK : FISH_LIGHT).map((f, i) => (
        <FishEl key={i} {...f} isDark={isDark} />
      ))}

      {/* Lanternfish — dark mode only */}
      {isDark && LANTERNFISH.map((f, i) => (
        <LanternFishEl key={`lantern-${i}`} {...f} />
      ))}

      {/* Particles / bubbles */}
      {isDark
        ? DARK_PARTICLES.map((p, i) => (
            <div key={i} className="ocean-particle absolute rounded-full pointer-events-none" style={{
              left: p.left,
              bottom: `-${p.size * 2}px`,
              width: p.size, height: p.size,
              background: i % 3 === 0 ? "#00ffe0" : i % 3 === 1 ? "#00bfff" : "#4dd9ff",
              boxShadow: `0 0 ${p.size * 2}px ${p.size}px ${i % 3 === 0 ? "rgba(0,255,224,0.4)" : "rgba(0,191,255,0.4)"}`,
              animationDuration: `${p.duration}s`,
              animationDelay: `${p.delay}s`,
              animationFillMode: "backwards",
            }} />
          ))
        : LIGHT_BUBBLES.map((cluster, ci) =>
            cluster.sizes.map((s, si) => (
              <div key={`${ci}-${si}`} className="ocean-bubble absolute rounded-full pointer-events-none" style={{
                left: `calc(${cluster.left} + ${si * 16}px)`,
                bottom: `${si * 20}px`,
                width: s, height: s,
                border: "1.5px solid rgba(255,255,255,0.75)",
                background: "radial-gradient(ellipse at 30% 30%, rgba(255,255,255,0.45) 0%, rgba(200,240,255,0.15) 60%, transparent 100%)",
                animationDuration: `${cluster.duration + si * 1.5}s`,
                animationDelay: `${cluster.delay + si * 0.8}s`,
                animationFillMode: "backwards",
              }} />
            ))
          )}
    </div>
  );
}
