import { Link, useLocation } from "wouter";
import {
  BookOpen,
  LayoutDashboard,
  PlusCircle,
  Settings2,
  UserCircle,
  LogOut,
} from "lucide-react";
import { Mascot } from "@/components/Mascot";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const navItems = [
  { title: "Tableau de bord", url: "/", icon: LayoutDashboard },
  { title: "Créer une fiche", url: "/creer", icon: PlusCircle },
  { title: "Mes fiches", url: "/mes-fiches", icon: BookOpen },
  { title: "Prompts", url: "/prompts", icon: Settings2 },
  { title: "Profil", url: "/profil", icon: UserCircle },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { signOut, user } = useAuth();
  const { data: profile } = useProfile();

  const getInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <Sidebar className="border-r border-sidebar-border shadow-xl">
      <SidebarHeader className="p-4 pt-6 pb-2">
        <Link href="/" className="flex items-center gap-3 px-2 group cursor-pointer">
          <div className="bg-white/10 p-1 rounded-xl group-hover:bg-white/20 transition-colors">
            <Mascot size={36} />
          </div>
          <span className="font-serif font-bold text-2xl tracking-tight text-white">
            Fish<span className="text-secondary">Up</span>
          </span>
        </Link>
      </SidebarHeader>

      <SidebarContent className="px-3 pt-6">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="gap-2">
              {navItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      className={`
                        py-6 rounded-xl transition-all duration-200
                        ${isActive
                          ? 'bg-white/20 text-white font-medium shadow-md shadow-black/10'
                          : 'text-sidebar-foreground/80 hover:bg-white/10 hover:text-white'
                        }
                      `}
                    >
                      <Link href={item.url} className="flex items-center gap-3 px-2">
                        <item.icon className={`h-5 w-5 ${isActive ? 'text-secondary' : ''}`} />
                        <span className="text-base">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 pb-6">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-3 px-2 py-2">
            <Avatar className="h-10 w-10 border-2 border-white/20 shadow-sm">
              <AvatarImage src={profile?.avatar_url || ''} />
              <AvatarFallback className="bg-white/10 text-white font-semibold">
                {profile?.nom ? getInitials(profile.nom) : 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col flex-1 min-w-0">
              <span className="text-sm font-semibold truncate text-white">
                {profile?.nom || 'Chargement...'}
              </span>
              <span className="text-xs text-white/60 truncate">
                {user?.email}
              </span>
            </div>
          </div>

          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton
                onClick={signOut}
                className="text-red-400 hover:bg-red-500/10 hover:text-red-300 py-5 rounded-xl transition-colors"
              >
                <LogOut className="h-5 w-5" />
                <span>Déconnexion</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}