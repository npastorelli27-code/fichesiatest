import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './use-auth';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

const STORAGE_KEY = 'fishup_seen_notifications';

function getSeenIds(): Set<string> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

function saveSeenIds(ids: Set<string>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...ids]));
  } catch {}
}

export type AppNotification = {
  id: string;
  fiche_id: string;
  from_nom: string | null;
  fiche_titre: string | null;
  fiche_matiere: string | null;
  created_at: string;
};

export function useNotifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [seenIds, setSeenIds] = useState<Set<string>>(getSeenIds);
  const [, navigate] = useLocation();

  const unreadCount = notifications.filter(n => !seenIds.has(n.id)).length;

  const fetchNotifications = useCallback(async () => {
    if (!user?.email) return;
    const { data, error } = await supabase
      .from('shared_fiches')
      .select('id, fiche_id, from_nom, fiche:fiches(titre, matiere), created_at')
      .eq('to_email', user.email)
      .order('created_at', { ascending: false })
      .limit(20);
    if (error) return;
    setNotifications(
      (data ?? []).map((row: any) => ({
        id: row.id,
        fiche_id: row.fiche_id,
        from_nom: row.from_nom,
        fiche_titre: row.fiche?.titre ?? null,
        fiche_matiere: row.fiche?.matiere ?? null,
        created_at: row.created_at,
      }))
    );
  }, [user?.email]);

  const markAllSeen = useCallback(() => {
    const newSeen = new Set([...seenIds, ...notifications.map(n => n.id)]);
    setSeenIds(newSeen);
    saveSeenIds(newSeen);
  }, [notifications, seenIds]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  useEffect(() => {
    if (!user?.email) return;

    const channel = supabase
      .channel(`notifs_${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'shared_fiches',
        },
        async (payload) => {
          if ((payload.new as any).to_email !== user.email) return;

          const { data } = await supabase
            .from('shared_fiches')
            .select('id, fiche_id, from_nom, fiche:fiches(titre, matiere), created_at')
            .eq('id', (payload.new as any).id)
            .single();

          if (!data) return;

          const newNotif: AppNotification = {
            id: data.id,
            fiche_id: data.fiche_id,
            from_nom: (data as any).from_nom,
            fiche_titre: (data.fiche as any)?.titre ?? null,
            fiche_matiere: (data.fiche as any)?.matiere ?? null,
            created_at: data.created_at,
          };

          setNotifications(prev => [newNotif, ...prev]);

          toast.info(`📬 Nouvelle fiche reçue !`, {
            description: `${(data as any).from_nom || 'Quelqu\'un'} t'a partagé "${(data.fiche as any)?.titre || 'une fiche'}"`,
            duration: 6000,
            action: {
              label: 'Voir',
              onClick: () => navigate('/fiches-partagees'),
            },
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.email, user?.id, navigate]);

  return { notifications, unreadCount, markAllSeen, refetch: fetchNotifications };
}
