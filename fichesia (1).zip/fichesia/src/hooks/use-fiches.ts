import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase, type Fiche } from '@/lib/supabase';
import { useAuth } from './use-auth';

export function useFiches() {
  const { user } = useAuth();
  
  return useQuery({
    queryKey: ['fiches', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('fiches')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      return data as Fiche[];
    },
    enabled: !!user,
  });
}

export function useFiche(id: string) {
  return useQuery({
    queryKey: ['fiche', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fiches')
        .select('*')
        .eq('id', id)
        .single();
        
      if (error) throw error;
      return data as Fiche;
    },
    enabled: !!id,
  });
}

export function useCreateFiche() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (fiche: Omit<Fiche, 'id' | 'created_at' | 'updated_at' | 'user_id'>) => {
      if (!user) throw new Error('Not authenticated');
      
      const { data, error } = await supabase
        .from('fiches')
        .insert([{ ...fiche, user_id: user.id }])
        .select()
        .single();
        
      if (error) throw error;
      return data as Fiche;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fiches'] });
    },
  });
}

export function useUpdateFiche() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, updates }: { id: string, updates: Partial<Fiche> }) => {
      const { data, error } = await supabase
        .from('fiches')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
        
      if (error) throw error;
      return data as Fiche;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['fiches'] });
      queryClient.invalidateQueries({ queryKey: ['fiche', variables.id] });
    },
  });
}

export function useDeleteFiche() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, path }: { id: string, path: string }) => {
      // First delete from storage
      const { error: storageError } = await supabase.storage
        .from('fiches-html')
        .remove([path]);
        
      if (storageError) console.error('Failed to delete file', storageError);

      // Then delete record
      const { error } = await supabase
        .from('fiches')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fiches'] });
    },
  });
}
