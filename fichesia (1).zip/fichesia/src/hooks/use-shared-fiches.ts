import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase, type Fiche } from '@/lib/supabase';
import { useAuth } from './use-auth';

export type SharedFiche = {
  id: string;
  fiche_id: string;
  from_user_id: string;
  from_nom: string | null;
  to_email: string;
  to_user_id: string | null;
  message: string | null;
  created_at: string;
  fiche?: Fiche;
};

export function useSharedFichesReceived() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['shared-fiches-received', user?.email],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('shared_fiches')
        .select('*, fiche:fiches(*)')
        .eq('to_email', user.email!)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erreur fiches reçues:', error);
        throw error;
      }
      return (data ?? []) as SharedFiche[];
    },
    enabled: !!user,
  });
}

export function useSharedFichesSent() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['shared-fiches-sent', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('shared_fiches')
        .select('*, fiche:fiches(*)')
        .eq('from_user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erreur fiches envoyées:', error);
        throw error;
      }
      return (data ?? []) as SharedFiche[];
    },
    enabled: !!user,
  });
}

export function useShareFiche() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({
      ficheId,
      toEmail,
      message,
      fromNom,
      ficheTitre,
      ficheMatiere,
    }: {
      ficheId: string;
      toEmail: string;
      message?: string;
      fromNom: string;
      ficheTitre: string;
      ficheMatiere: string;
    }) => {
      if (!user) throw new Error('Non authentifié');

      // Vérifier si déjà partagé
      const { data: existing, error: checkError } = await supabase
        .from('shared_fiches')
        .select('id')
        .eq('fiche_id', ficheId)
        .eq('to_email', toEmail)
        .maybeSingle();

      if (checkError) throw checkError;
      if (existing) throw new Error('Cette fiche a déjà été partagée avec cet email.');

      // Insérer le partage avec le nom de l'expéditeur
      const { data, error } = await supabase
        .from('shared_fiches')
        .insert([{
          fiche_id: ficheId,
          from_user_id: user.id,
          from_nom: fromNom,
          to_email: toEmail,
          message: message || null,
        }])
        .select('*, fiche:fiches(*)')
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shared-fiches-sent'] });
      queryClient.invalidateQueries({ queryKey: ['shared-fiches-received'] });
    },
  });
}

export function useDeleteSharedFiche() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('shared_fiches')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shared-fiches-received'] });
      queryClient.invalidateQueries({ queryKey: ['shared-fiches-sent'] });
    },
  });
}
