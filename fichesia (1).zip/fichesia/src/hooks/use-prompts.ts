import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase, type Prompt } from '@/lib/supabase';
import { useAuth } from './use-auth';

const DEFAULT_PROMPT = {
  nom: "Fiche pédagogique standard",
  matiere: "Général",
  contenu: `Tu es un expert en pédagogie scolaire et universitaire spécialisé dans la création de fiches de révision synthétiques et visuelles.

MISSION : À partir des documents fournis, créer une fiche de révision SYNTHÉTIQUE en HTML autonome. Une fiche de révision n'est PAS un cours recopié : c'est une distillation des points essentiels, des définitions-clés et des distinctions importantes. Sois concis, percutant, et va à l'essentiel.

SORTIE ATTENDUE : Un fichier HTML COMPLET commençant OBLIGATOIREMENT par <!DOCTYPE html>.
INTERDIT ABSOLU : Jamais de blocs markdown (\`\`\`html). Jamais de texte avant <!DOCTYPE html> ou après </html>.

STYLE DE CONTENU À ADOPTER :
- Les définitions importantes → dans une <div class="key-box"> avec les mots-clés en <strong>
- Les listes → courtes, 2-4 items max par liste, formulations télégraphiques
- Les articles de loi → citer uniquement le numéro et la règle en une ligne, jamais le texte intégral
- Les exemples → 2-3 mots suffisent (ex : hypothèque, gage)
- Chaque section doit tenir en moins de 15 lignes
- Préférer les flèches (→) et abréviations aux phrases longues

EXEMPLE DE BON RENDU pour une notion :
<h3>A) Droits réels</h3>
<div class="key-box">Pouvoir direct sur une <strong>chose</strong> (rapport personne → chose).</div>
<ul>
  <li><strong>Droit de suite</strong> : suit la chose en toutes mains.</li>
  <li><strong>Droit de préférence</strong> : priorité sur les autres créanciers.</li>
</ul>

EXEMPLE DE MAUVAIS RENDU À ÉVITER :
<p>Un droit réel est un pouvoir juridique directement exercé par une personne sur une chose, procurant à son titulaire tout ou partie de l'utilité économique de cette chose. C'est un rapport juridique immédiat et direct entre une personne et une chose...</p>

TEMPLATE HTML À UTILISER EXACTEMENT :

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Fiche – [TITRE]</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
body { background:#e5e5e5; padding:20px; font-family:'Inter',sans-serif; color:#1f2937; }
.notebook-page { background:#ffffff; max-width:750px; margin:auto; padding:40px 55px 40px 75px; min-height:1800px; box-shadow:0 4px 15px rgba(0,0,0,0.1); background-image:linear-gradient(to bottom,#d6d6e7 1px,transparent 1px); background-size:100% 25px; line-height:1.6; position:relative; }
.notebook-page::before { content:''; position:absolute; left:55px; top:0; bottom:0; width:1px; background:#ff0000; }
h1,h2,h3,h4 { font-weight:800; color:#7c3aed; margin-top:18px; margin-bottom:8px; }
h1 { font-size:1.7rem; } h2 { font-size:1.4rem; } h3 { font-size:1.2rem; } h4 { font-size:1.05rem; }
p,li { font-size:0.95rem; }
.key-box { background:#f5f3ff; border-left:5px solid #a78bfa; padding:10px 15px; margin:15px 0; border-radius:5px; font-size:0.95rem; }
ul { margin-left:20px; }
@media print { body { background:#ffffff; padding:0; } .notebook-page { box-shadow:none; margin:0 auto; max-width:750px; width:100%; min-height:100vh; } }
</style>
</head>
<body>
<div class="notebook-page">
<header style="text-align:center;margin-bottom:30px;">
  <h1>Fiche – [TITRE DU CHAPITRE]</h1>
  <p style="font-size:0.9rem;color:#6b7280;">[sous-titre listant les thèmes couverts, séparés par des tirets]</p>
</header>
[SECTIONS I. II. III. en h2 → sous-sections A) B) en h3 → points 1. 2. en h4 → définitions en key-box → listes courtes en ul/li]
</div>
</body>
</html>

RÈGLES DE CONTENU :
- Sections numérotées en chiffres romains (I, II, III…) avec h2
- Sous-sections en lettres (A, B…) avec h3, points numérotés (1. 2.) avec h4
- Définitions et notions-clés dans <div class="key-box">
- Listes avec <ul><li>, termes importants en <strong>
- Couvre TOUT le contenu des documents fournis sans rien omettre
- Langue : français`,
  is_default: true,
};

export function usePrompts() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  
  return useQuery({
    queryKey: ['prompts', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      let { data, error } = await supabase
        .from('prompts')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });
        
      if (error) throw error;
      
      // Auto-create default prompt if none exist
      if (!data || data.length === 0) {
        const { data: newData, error: insertError } = await supabase
          .from('prompts')
          .insert([{ ...DEFAULT_PROMPT, user_id: user.id }])
          .select();
          
        if (insertError) throw insertError;
        data = newData;
      }
      
      return data as Prompt[];
    },
    enabled: !!user,
  });
}

export function useCreatePrompt() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (prompt: Omit<Prompt, 'id' | 'created_at' | 'user_id'>) => {
      if (!user) throw new Error('Not authenticated');
      
      const { data, error } = await supabase
        .from('prompts')
        .insert([{ ...prompt, user_id: user.id }])
        .select()
        .single();
        
      if (error) throw error;
      return data as Prompt;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
    },
  });
}

export function useUpdatePrompt() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, updates }: { id: string, updates: Partial<Prompt> }) => {
      const { data, error } = await supabase
        .from('prompts')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
        
      if (error) throw error;
      return data as Prompt;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
    },
  });
}

export function useDeletePrompt() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('prompts')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
    },
  });
}
