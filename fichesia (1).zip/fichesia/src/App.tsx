import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { CreerProvider } from "@/contexts/creer-context";
import NotFound from "@/pages/not-found";
import { OceanBackground } from "@/components/ui/OceanBackground";
import { NotificationBell } from "@/components/ui/NotificationBell";

import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import CreerFiche from "@/pages/creer";
import MesFiches from "@/pages/mes-fiches";
import FicheView from "@/pages/fiche-view";
import Prompts from "@/pages/prompts";
import Profil from "@/pages/profil";
import FichesPartagees from "@/pages/fiches-partagees";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" component={Dashboard} />
      <Route path="/creer" component={CreerFiche} />
      <Route path="/mes-fiches" component={MesFiches} />
      <Route path="/fiche/:id" component={FicheView} />
      <Route path="/prompts" component={Prompts} />
      <Route path="/profil" component={Profil} />
      <Route path="/fiches-partagees" component={FichesPartagees} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppWithBackground() {
  const [location] = useLocation();
  const { user } = useAuth();
  const isLogin = location === "/login";

  return (
    <>
      {!isLogin && <OceanBackground />}
      <div className="relative" style={{ zIndex: 10 }}>
        <Router />
      </div>
      {user && !isLogin && (
        <div className="fixed top-4 right-4 z-50">
          <NotificationBell />
        </div>
      )}
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
        <TooltipProvider>
          <AuthProvider>
            <CreerProvider>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <AppWithBackground />
                <Toaster position="top-right" />
              </WouterRouter>
            </CreerProvider>
          </AuthProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
